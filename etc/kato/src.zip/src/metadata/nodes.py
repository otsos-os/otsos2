from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Union


@dataclass
class CTExpr:
	"""Compile-time expression node."""
	pass


@dataclass
class CTInt(CTExpr):
	value: int = 0


@dataclass
class CTFloat(CTExpr):
	value: float = 0.0


@dataclass
class CTString(CTExpr):
	value: str = ""


@dataclass
class CTBool(CTExpr):
	value: bool = False


@dataclass
class CTRef(CTExpr):
	name: str = ""


@dataclass
class CTBinary(CTExpr):
	op: str = ""
	left: CTExpr = None
	right: CTExpr = None


@dataclass
class CTUnary(CTExpr):
	op: str = ""
	operand: CTExpr = None


@dataclass
class CTIf(CTExpr):
	cond: CTExpr = None
	then_branch: CTExpr = None
	else_branch: CTExpr = None


@dataclass
class TypeDef:
	"""Type definition from metadata DSL."""
	name: str = ""
	kind: str = ""
	properties: Dict[str, CTExpr] = field(default_factory=dict)
	fields: Dict[str, str] = field(default_factory=dict)
	field_arrays: Dict[str, CTExpr] = field(default_factory=dict)

	def get(self, key):
		return self.properties.get(key)

	def is_integer(self):
		return self.kind == "integer"

	def is_float(self):
		return self.kind == "float"

	def is_bool(self):
		return self.kind == "boolean"

	def is_struct(self):
		return self.kind == "struct"

	def is_enum(self):
		return self.kind == "enum"

	def is_pointer(self):
		return self.kind == "pointer"

	def is_char(self):
		return self.kind == "character"

	def is_void(self):
		return self.kind == "empty"

	def c_type(self, safety: bool = False) -> str:
		if self.is_integer():
			if safety:
				bits = self._int_prop("bits", 32)
				signed = self._bool_prop("signed", True)
				if bits == 8:
					return "int8_t" if signed else "uint8_t"
				elif bits == 16:
					return "int16_t" if signed else "uint16_t"
				elif bits == 32:
					return "int32_t" if signed else "uint32_t"
				elif bits == 64:
					return "int64_t" if signed else "uint64_t"
				return "int32_t"
			else:
				bits = self._int_prop("bits", 32)
				signed = self._bool_prop("signed", True)
				if bits == 8:
					return "char" if signed else "unsigned char"
				elif bits == 16:
					return "short" if signed else "unsigned short"
				elif bits == 32:
					return "int" if signed else "unsigned int"
				elif bits == 64:
					return "long long" if signed else "unsigned long long"
				return "int"
		if self.is_float():
			bits = self._int_prop("bits", 32)
			return "double" if bits == 64 else "float"
		if self.is_bool():
			return "bool"
		if self.is_char():
			return "char"
		if self.is_void():
			return "void"
		return self.name

	def _int_prop(self, key, default=0):
		v = self.properties.get(key)
		if v is None:
			return default
		return v

	def _bool_prop(self, key, default=False):
		v = self.properties.get(key)
		if v is None:
			return default
		return v


@dataclass
class FuncContract:
	"""Function contract from metadata DSL."""
	name: str = ""
	kind: str = "function"
	args: Dict[str, str] = field(default_factory=dict)
	arg_order: List[str] = field(default_factory=list)
	returns: str = "void"
	pure: bool = False
	mutates: List[str] = field(default_factory=list)
	inline_mode: str = "auto"
	unroll_mode: str = "auto"
	unroll_count: int = 0
	complexity_max: int = 0
	allocates: bool = False
	recurses: bool = False
	threadsafe: bool = False
	restrict: Optional[bool] = None

	def is_start(self):
		return self.kind == "start"

	def is_procedure(self):
		return self.kind == "procedure" or self.returns == "void"


@dataclass
class ConstDef:
	name: str = ""
	value: CTExpr = None


@dataclass
class SpaceDecl:
	visibility: str = ""
	symbols: List[str] = field(default_factory=list)


@dataclass
class LetBinding:
	name: str = ""
	value: CTExpr = None


@dataclass
class AssertStmt:
	expr: CTExpr = None


@dataclass
class IfBlock:
	cond: CTExpr = None
	then_directives: List[Any] = field(default_factory=list)
	else_directives: List[Any] = field(default_factory=list)


@dataclass
class EmitC:
	code: str = ""


@dataclass
class CInclude:
	header: str = ""


@dataclass
class CFlag:
	flag: str = ""


@dataclass
class CName:
	name: str = ""


@dataclass
class CPrefix:
	prefix: str = ""


@dataclass
class CExport:
	symbol: str = ""


@dataclass
class ImportEntry:
	module_name: str = ""


@dataclass
class BoundsDirective:
	mode: str = "none"
	target: Optional[str] = None


@dataclass
class OverflowDirective:
	mode: str = "unchecked"
	target: Optional[str] = None


@dataclass
class NullCheckDirective:
	mode: str = "never"
	target: Optional[str] = None


@dataclass
class DivCheckDirective:
	mode: str = "never"
	target: Optional[str] = None


@dataclass
class RangeCheckDirective:
	mode: str = "never"
	target: Optional[str] = None


@dataclass
class InitDirective:
	mode: str = "none"


@dataclass
class AllocDirective:
	strategy: str = "dynamic"
	size: CTExpr = None


@dataclass
class ThreadDirective:
	mode: str = "single"


@dataclass
class ComplexityDirective:
	max_complexity: int = 0


@dataclass
class StackDirective:
	max_bytes: CTExpr = None


@dataclass
class PanicDirective:
	mode: str = "halt"


@dataclass
class LayoutDirective:
	layout: str = "soa"


@dataclass
class OptDirective:
	key: str = ""
	target: Optional[str] = None


@dataclass
class InlineDirective:
	mode: str = "auto"
	target: Optional[str] = None


@dataclass
class UnrollDirective:
	mode: str = "auto"
	count: int = 0
	target: Optional[str] = None


@dataclass
class Metadata:
	mode: str = "speed"
	layout: str = "soa"
	type_defs: Dict[str, TypeDef] = field(default_factory=dict)
	func_contracts: Dict[str, FuncContract] = field(default_factory=dict)
	const_defs: Dict[str, ConstDef] = field(default_factory=dict)
	space_decls: List[SpaceDecl] = field(default_factory=list)
	let_bindings: Dict[str, CTExpr] = field(default_factory=dict)
	asserts: List[AssertStmt] = field(default_factory=list)
	if_blocks: List[IfBlock] = field(default_factory=list)
	emit_cs: List[EmitC] = field(default_factory=list)
	c_includes: List[CInclude] = field(default_factory=list)
	c_flags: List[CFlag] = field(default_factory=list)
	c_names: Dict[str, str] = field(default_factory=dict)
	c_prefix: Optional[CPrefix] = None
	c_no_prefix: bool = False
	c_exports: List[CExport] = field(default_factory=list)
	imports: List[ImportEntry] = field(default_factory=list)
	bounds: BoundsDirective = field(default_factory=BoundsDirective)
	overflow: OverflowDirective = field(default_factory=OverflowDirective)
	null_check: NullCheckDirective = field(default_factory=NullCheckDirective)
	div_check: DivCheckDirective = field(default_factory=DivCheckDirective)
	range_check: RangeCheckDirective = field(default_factory=RangeCheckDirective)
	init: InitDirective = field(default_factory=InitDirective)
	alloc: AllocDirective = field(default_factory=AllocDirective)
	thread: ThreadDirective = field(default_factory=ThreadDirective)
	complexity: ComplexityDirective = field(default_factory=ComplexityDirective)
	stack: StackDirective = field(default_factory=StackDirective)
	panic: PanicDirective = field(default_factory=PanicDirective)
	per_func_bounds: Dict[str, BoundsDirective] = field(default_factory=dict)
	per_func_overflow: Dict[str, OverflowDirective] = field(default_factory=dict)
	per_func_null_check: Dict[str, NullCheckDirective] = field(default_factory=dict)
	per_func_inline: Dict[str, str] = field(default_factory=dict)
	per_func_unroll: Dict[str, UnrollDirective] = field(default_factory=dict)
	opt_directives: List[OptDirective] = field(default_factory=list)
	transforms: list = field(default_factory=list)
	transform_disables: list = field(default_factory=list)

	def is_safety(self):
		return self.mode == "safety"

	def is_speed(self):
		return self.mode == "speed"

	def get_type_def(self, name):
		return self.type_defs.get(name)

	def get_func_contract(self, name):
		return self.func_contracts.get(name)

	def is_exported(self, name):
		for s in self.space_decls:
			if s.visibility == "export" and name in s.symbols:
				return True
		return False

	def is_internal(self, name):
		for s in self.space_decls:
			if s.visibility == "internal" and name in s.symbols:
				return True
		return False

	def get_inline_mode(self, name):
		if name in self.per_func_inline:
			return self.per_func_inline[name]
		contract = self.func_contracts.get(name)
		if contract:
			return contract.inline_mode
		return "auto"

	def get_unroll(self, name):
		if name in self.per_func_unroll:
			return self.per_func_unroll[name]
		contract = self.func_contracts.get(name)
		if contract:
			return UnrollDirective(mode=contract.unroll_mode, count=contract.unroll_count, target=name)
		return UnrollDirective()

	def get_c_name(self, name):
		if name in self.c_names:
			return self.c_names[name]
		if self.c_prefix and not self.c_no_prefix:
			return self.c_prefix.prefix + name
		return name

	def get_bounds_mode(self, name=None):
		if name and name in self.per_func_bounds:
			return self.per_func_bounds[name].mode
		return self.bounds.mode

	def get_overflow_mode(self, name=None):
		if name and name in self.per_func_overflow:
			return self.per_func_overflow[name].mode
		return self.overflow.mode

	def get_null_check_mode(self, name=None):
		if name and name in self.per_func_null_check:
			return self.per_func_null_check[name].mode
		return self.null_check.mode

	def get_alloc_strategy(self):
		return self.alloc.strategy

	def get_panic_mode(self):
		return self.panic.mode

	def get_func_restrict(self, name):
		contract = self.func_contracts.get(name)
		if contract and contract.restrict is not None:
			return contract.restrict
		if self.is_safety():
			return False
		return True
