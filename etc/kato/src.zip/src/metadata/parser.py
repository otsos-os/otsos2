from typing import List, Optional

from src.lexer.tokens import Token, TokenType
from src.metadata.nodes import (
	Metadata, TypeDef, FuncContract, ConstDef, SpaceDecl,
	LetBinding, AssertStmt, IfBlock, EmitC,
	CInclude, CFlag, CName, CPrefix, CExport, ImportEntry,
	BoundsDirective, OverflowDirective, NullCheckDirective,
	DivCheckDirective, RangeCheckDirective, InitDirective,
	AllocDirective, ThreadDirective, ComplexityDirective,
	StackDirective, PanicDirective, LayoutDirective,
	OptDirective, InlineDirective, UnrollDirective,
	CTInt, CTFloat, CTString, CTBool, CTRef, CTBinary, CTUnary, CTIf,
)


class MetadataParseError(Exception):

	def __init__(self, msg, line, col, filename):
		self.msg = msg
		self.line = line
		self.col = col
		self.filename = filename
		super().__init__(f"metadata error: {filename}:{line}:{col}: {msg}")


class MetadataParser:

	def __init__(self, tokens: List[Token]):
		self.tokens = tokens
		self.pos = 0
		self.filename = "<input>"

	def _peek(self, offset=0):
		idx = self.pos + offset
		if idx >= len(self.tokens):
			return self.tokens[-1]
		return self.tokens[idx]

	def _advance(self):
		tok = self.tokens[self.pos]
		if self.pos < len(self.tokens) - 1:
			self.pos += 1
		return tok

	def _expect(self, ttype, msg=None):
		tok = self._peek()
		if tok.type != ttype:
			err = msg or f"expected {ttype.name}, got {tok.type.name} ('{tok.value}')"
			self._error(err)
		return self._advance()

	def _error(self, msg):
		tok = self._peek()
		raise MetadataParseError(msg, tok.line, tok.col, self.filename)

	def _skip_newlines(self):
		pass

	def parse(self):
		meta = Metadata()
		self._expect(TokenType.META_START)
		self.filename = self._peek().filename

		while self._peek().type not in (TokenType.META_END, TokenType.EOF):
			if self._peek().type == TokenType.META_DOLLAR:
				self._parse_directive(meta)
			else:
				self._advance()

		if self._peek().type == TokenType.META_END:
			self._advance()

		return meta

	def _parse_directive(self, meta):
		self._expect(TokenType.META_DOLLAR)
		directive_tok = self._advance()
		directive = directive_tok.value

		if directive == "mode":
			meta.mode = self._advance().value

		elif directive == "layout":
			meta.layout = self._advance().value
			meta.layout = LayoutDirective(layout=meta.layout).layout

		elif directive == "define":
			self._parse_define(meta)

		elif directive == "space":
			self._parse_space(meta)

		elif directive == "let":
			self._parse_let(meta)

		elif directive == "assert":
			self._parse_assert(meta)

		elif directive == "if":
			self._parse_if_block(meta)

		elif directive == "emit":
			self._parse_emit(meta)

		elif directive == "opt":
			self._parse_opt(meta)

		elif directive == "inline":
			self._parse_inline(meta)

		elif directive == "unroll":
			self._parse_unroll(meta)

		elif directive == "bounds":
			mode = self._advance().value
			target = None
			if self._peek().type == TokenType.IDENT:
				target = self._advance().value
			d = BoundsDirective(mode=mode, target=target)
			if target:
				meta.per_func_bounds[target] = d
			else:
				meta.bounds = d

		elif directive == "overflow":
			mode = self._advance().value
			target = None
			if self._peek().type == TokenType.IDENT:
				target = self._advance().value
			d = OverflowDirective(mode=mode, target=target)
			if target:
				meta.per_func_overflow[target] = d
			else:
				meta.overflow = d

		elif directive == "null_check":
			mode = self._advance().value
			target = None
			if self._peek().type == TokenType.IDENT:
				target = self._advance().value
			d = NullCheckDirective(mode=mode, target=target)
			if target:
				meta.per_func_null_check[target] = d
			else:
				meta.null_check = d

		elif directive == "div_check":
			mode = self._advance().value
			meta.div_check = DivCheckDirective(mode=mode)

		elif directive == "range_check":
			mode = self._advance().value
			target = None
			if self._peek().type == TokenType.IDENT:
				target = self._advance().value
			meta.range_check = RangeCheckDirective(mode=mode, target=target)

		elif directive == "init":
			mode = self._advance().value
			meta.init = InitDirective(mode=mode)

		elif directive == "alloc":
			strategy = self._advance().value
			size = None
			if self._peek().type == TokenType.LPAREN:
				self._advance()
				size = self._parse_ct_expr()
				if self._peek().type == TokenType.RPAREN:
					self._advance()
			meta.alloc = AllocDirective(strategy=strategy, size=size)

		elif directive == "thread":
			mode = self._advance().value
			meta.thread = ThreadDirective(mode=mode)

		elif directive == "complexity":
			self._advance()
			if self._peek().type == TokenType.LPAREN:
				self._advance()
				val = int(self._advance().value)
				if self._peek().type == TokenType.RPAREN:
					self._advance()
			else:
				val = int(self._advance().value)
			meta.complexity = ComplexityDirective(max_complexity=val)

		elif directive == "stack":
			self._advance()
			if self._peek().type == TokenType.LPAREN:
				self._advance()
				expr = self._parse_ct_expr()
				if self._peek().type == TokenType.RPAREN:
					self._advance()
			else:
				expr = self._parse_ct_expr()
			meta.stack = StackDirective(max_bytes=expr)

		elif directive == "panic":
			mode = self._advance().value
			meta.panic = PanicDirective(mode=mode)

		elif directive == "c_include":
			value = self._advance().value
			meta.c_includes.append(CInclude(header=value.strip('"')))

		elif directive == "c_flag":
			value = self._advance().value
			meta.c_flags.append(CFlag(flag=value.strip('"')))

		elif directive == "c_name":
			name = self._advance().value
			meta.c_names[name] = name

		elif directive == "c_prefix":
			value = self._advance().value
			meta.c_prefix = CPrefix(prefix=value.strip('"'))

		elif directive == "c_no_prefix":
			meta.c_no_prefix = True

		elif directive == "c_export":
			value = self._advance().value
			meta.c_exports.append(CExport(symbol=value))

		elif directive == "import":
			value = self._advance().value
			meta.imports.append(ImportEntry(module_name=value))

		elif directive == "transform":
			self._parse_transform(meta)

		elif directive == "transform_disable":
			name = self._advance().value
			meta.transform_disables.append(name)

		else:
			self._error(f"unknown metadata directive: ${directive}")

	def _parse_transform(self, meta):
		from src.transform.nodes import TransformRule

		name = self._advance().value
		rule = TransformRule(name=name)

		while self._peek().type not in (TokenType.META_DOLLAR, TokenType.META_END, TokenType.EOF):
			if self._peek().type == TokenType.IDENT:
				key = self._advance().value
				if self._peek().type == TokenType.COLON:
					self._advance()

					if key == "match":
						construct = self._advance().value
						rule.match_construct = construct
						if self._peek().type == TokenType.LPAREN:
							self._advance()
							rule.match_op = self._advance().value
							if self._peek().type == TokenType.RPAREN:
								self._advance()

					elif key == "condition":
						rule.condition = self._parse_ct_expr()

					elif key in ("before", "after", "replace"):
						template = self._parse_c_template()
						if key == "before":
							rule.before_template = template
						elif key == "after":
							rule.after_template = template
						elif key == "replace":
							rule.replace_template = template
					else:
						self._advance()
				else:
					pass
			else:
				self._advance()

		meta.transforms.append(rule)

	def _parse_c_template(self) -> str:
		self._expect(TokenType.LBRACE)
		start = self.pos
		depth = 1

		while self.pos < len(self.tokens) and depth > 0:
			if self._peek().type == TokenType.LBRACE:
				depth += 1
			elif self._peek().type == TokenType.RBRACE:
				depth -= 1
				if depth == 0:
					break
			self._advance()

		parts = []
		end = self.pos
		for i in range(start, end):
			tok = self.tokens[i]
			if tok.type == TokenType.STRING_LIT:
				parts.append(tok.value)
			elif tok.type in (TokenType.IDENT, TokenType.META_DIRECTIVE, TokenType.IF, TokenType.ELSE):
				parts.append(tok.value)
			elif tok.type == TokenType.INT_LIT:
				parts.append(tok.value)
			elif tok.type == TokenType.FLOAT_LIT:
				parts.append(tok.value)
			elif tok.type in (TokenType.SEMICOLON,):
				parts.append(";")
			elif tok.type in (TokenType.COMMA,):
				parts.append(",")
			elif tok.type in (TokenType.LPAREN,):
				parts.append("(")
			elif tok.type in (TokenType.RPAREN,):
				parts.append(")")
			elif tok.type in (TokenType.LBRACKET,):
				parts.append("[")
			elif tok.type in (TokenType.RBRACKET,):
				parts.append("]")
			elif tok.type in (TokenType.PLUS, TokenType.MINUS, TokenType.STAR, TokenType.SLASH):
				parts.append(tok.value)
			elif tok.type in (TokenType.LT, TokenType.GT, TokenType.LEQ, TokenType.GEQ, TokenType.EQ, TokenType.NEQ):
				parts.append(tok.value)
			elif tok.type in (TokenType.AND, TokenType.OR, TokenType.NOT):
				parts.append(tok.value)
			elif tok.type == TokenType.ASSIGN:
				parts.append("=")
			elif tok.type == TokenType.DOT:
				parts.append(".")
			elif tok.type == TokenType.COLON:
				parts.append(":")
			elif tok.type == TokenType.AMP:
				parts.append("&")
			elif tok.type == TokenType.PIPE:
				parts.append("|")
			elif tok.type == TokenType.LBRACE:
				parts.append("{")
			elif tok.type == TokenType.RBRACE:
				parts.append("}")
			elif tok.type == TokenType.PERCENT:
				parts.append("%")
			elif tok.type == TokenType.DOUBLE_SLASH:
				parts.append("//")
			elif tok.type == TokenType.TILDE:
				parts.append("~")
			elif tok.type == TokenType.CARET:
				parts.append("^")
			elif tok.type == TokenType.SHL:
				parts.append("<<")
			elif tok.type == TokenType.SHR:
				parts.append(">>")

		if self._peek().type == TokenType.RBRACE:
			self._advance()

		raw = " ".join(parts)
		return raw

	def _parse_define(self, meta):
		self._expect(TokenType.META_PERCENT)
		kind_tok = self._advance()

		if kind_tok.value == "type":
			name = self._advance().value
			self._expect(TokenType.META_AS)
			type_kind = self._advance().value
			td = TypeDef(name=name, kind=type_kind)
			self._parse_type_properties(td)
			meta.type_defs[name] = td

		elif kind_tok.value == "func":
			name = self._advance().value
			self._expect(TokenType.META_AS)
			func_kind = self._advance().value
			fc = FuncContract(name=name, kind=func_kind)
			self._parse_func_properties(fc)
			meta.func_contracts[name] = fc

		elif kind_tok.value == "const":
			name = self._advance().value
			self._expect(TokenType.ASSIGN)
			expr = self._parse_ct_expr()
			meta.const_defs[name] = ConstDef(name=name, value=expr)

		else:
			self._error(f"unknown define kind: %{kind_tok.value}")

	def _parse_type_properties(self, td: TypeDef):
		while self._peek().type not in (TokenType.META_DOLLAR, TokenType.META_END, TokenType.EOF):
			if self._peek().type == TokenType.IDENT:
				key = self._advance().value
				if self._peek().type == TokenType.COLON:
					self._advance()
					if key == "fields":
						self._parse_fields_block(td)
					else:
						expr = self._parse_ct_value()
						td.properties[key] = expr
				else:
					pass
			else:
				self._advance()

	def _parse_fields_block(self, td: TypeDef):
		self._expect(TokenType.LBRACE)
		while self._peek().type != TokenType.RBRACE:
			if self._peek().type == TokenType.IDENT:
				field_name = self._advance().value
				self._expect(TokenType.COLON)
				type_name = self._advance().value
				td.fields[field_name] = type_name
				if self._peek().type == TokenType.LBRACKET:
					self._advance()
					arr_expr = self._parse_ct_expr()
					td.field_arrays[field_name] = arr_expr
					self._expect(TokenType.RBRACKET)
				if self._peek().type == TokenType.COMMA:
					self._advance()
			else:
				self._advance()
		self._expect(TokenType.RBRACE)

	def _parse_func_properties(self, fc: FuncContract):
		while self._peek().type not in (TokenType.META_DOLLAR, TokenType.META_END, TokenType.EOF):
			if self._peek().type == TokenType.IDENT:
				key = self._advance().value
				if self._peek().type == TokenType.COLON:
					self._advance()
					if key == "args":
						self._parse_args_block(fc)
					elif key == "returns":
						fc.returns = self._advance().value
					elif key == "pure":
						fc.pure = self._advance().value == "true"
					elif key == "mutates":
						self._parse_mutates_block(fc)
					elif key == "inline":
						fc.inline_mode = self._advance().value
					elif key == "unroll":
						mode = self._advance().value
						fc.unroll_mode = mode
						if mode == "count" and self._peek().type == TokenType.LPAREN:
							self._advance()
							fc.unroll_count = int(self._advance().value)
							if self._peek().type == TokenType.RPAREN:
								self._advance()
					elif key == "complexity":
						self._advance()
						if self._peek().type == TokenType.LPAREN:
							self._advance()
							fc.complexity_max = int(self._advance().value)
							if self._peek().type == TokenType.RPAREN:
								self._advance()
						else:
							fc.complexity_max = int(self._advance().value)
					elif key == "allocates":
						fc.allocates = self._advance().value == "true"
					elif key == "recurses":
						fc.recurses = self._advance().value == "true"
					elif key == "threadsafe":
						fc.threadsafe = self._advance().value == "true"
					elif key == "restrict":
						val = self._advance().value
						fc.restrict = True if val == "true" else False if val == "false" else None
					else:
						self._advance()
				else:
					pass
			else:
				self._advance()

	def _parse_args_block(self, fc: FuncContract):
		self._expect(TokenType.LBRACE)
		if self._peek().type == TokenType.IDENT and self._peek().value == "void":
			self._advance()
			self._expect(TokenType.RBRACE)
			return
		while self._peek().type != TokenType.RBRACE:
			if self._peek().type == TokenType.IDENT:
				arg_name = self._advance().value
				self._expect(TokenType.COLON)
				arg_type = self._advance().value
				while self._peek().type == TokenType.STAR:
					arg_type += "*"
					self._advance()
				fc.args[arg_name] = arg_type
				fc.arg_order.append(arg_name)
				if self._peek().type == TokenType.COMMA:
					self._advance()
			else:
				self._advance()
		self._expect(TokenType.RBRACE)

	def _parse_mutates_block(self, fc: FuncContract):
		self._expect(TokenType.LBRACE)
		while self._peek().type != TokenType.RBRACE:
			if self._peek().type == TokenType.IDENT:
				fc.mutates.append(self._advance().value)
				if self._peek().type == TokenType.COMMA:
					self._advance()
			else:
				self._advance()
		self._expect(TokenType.RBRACE)

	def _parse_let(self, meta):
		name = self._advance().value
		self._expect(TokenType.ASSIGN)
		expr = self._parse_ct_expr()
		meta.let_bindings[name] = expr

	def _parse_assert(self, meta):
		expr = self._parse_ct_expr()
		meta.asserts.append(AssertStmt(expr=expr))

	def _parse_if_block(self, meta):
		cond = self._parse_ct_expr()
		if self._peek().type == TokenType.IDENT and self._peek().value == "then":
			self._advance()
		while self._peek().type not in (TokenType.META_END, TokenType.EOF):
			if self._peek().type == TokenType.META_DOLLAR:
				next_tok = self._peek(1)
				if next_tok.type == TokenType.ELSE or (next_tok.type == TokenType.IDENT and next_tok.value == "end"):
					break
				self._parse_directive(meta)
			else:
				self._advance()
		if self._peek().type == TokenType.META_DOLLAR and self._peek(1).type == TokenType.ELSE:
			self._advance()
			self._advance()
			while self._peek().type not in (TokenType.META_END, TokenType.EOF):
				if self._peek().type == TokenType.META_DOLLAR:
					next_tok = self._peek(1)
					if next_tok.type == TokenType.IDENT and next_tok.value == "end":
						break
					self._parse_directive(meta)
				else:
					self._advance()
		if self._peek().type == TokenType.META_DOLLAR and self._peek(1).type == TokenType.IDENT and self._peek(1).value == "end":
			self._advance()
			self._advance()
		meta.if_blocks.append(IfBlock(cond=cond))

	def _parse_emit(self, meta):
		prefix = self._advance().value
		if prefix == "c":
			if self._peek().type == TokenType.STRING_LIT:
				value = self._advance().value
				meta.emit_cs.append(EmitC(code=value.strip('"')))

	def _parse_opt(self, meta):
		value = self._advance().value
		target = None
		if self._peek().type == TokenType.IDENT and self._peek().value not in (
			"vectorize", "no_vectorize", "restrict", "no_restrict",
			"simd", "no_simd"
		):
			target = self._advance().value
		meta.opt_directives.append(OptDirective(key=value, target=target))

	def _parse_inline(self, meta):
		mode = self._advance().value
		target = None
		if self._peek().type == TokenType.IDENT and self._peek().value not in ("always", "never", "auto"):
			target = self._advance().value
		if target:
			meta.per_func_inline[target] = mode
		else:
			pass

	def _parse_unroll(self, meta):
		if self._peek().type == TokenType.IDENT and self._peek().value == "count":
			self._advance()
			if self._peek().type == TokenType.LPAREN:
				self._advance()
				count = int(self._advance().value)
				if self._peek().type == TokenType.RPAREN:
					self._advance()
			else:
				count = int(self._advance().value)
			mode = "count"
		elif self._peek().type == TokenType.IDENT and self._peek().value in ("auto", "no"):
			mode = self._advance().value
			count = 0
		else:
			mode = "auto"
			count = 0
		target = None
		if self._peek().type == TokenType.IDENT:
			target = self._advance().value
		d = UnrollDirective(mode=mode, count=count, target=target)
		if target:
			meta.per_func_unroll[target] = d

	def _parse_space(self, meta):
		self._expect(TokenType.META_PERCENT)
		visibility = self._advance().value
		symbols = []
		while self._peek().type not in (TokenType.META_DOLLAR, TokenType.META_END, TokenType.EOF):
			if self._peek().type == TokenType.COMMA:
				self._advance()
				continue
			symbols.append(self._advance().value)
		meta.space_decls.append(SpaceDecl(visibility=visibility, symbols=symbols))

	def _parse_ct_value(self):
		if self._peek().type == TokenType.LBRACE:
			return self._parse_ct_expr()
		if self._peek().type == TokenType.IDENT:
			val = self._advance().value
			if val == "true":
				return CTBool(value=True)
			if val == "false":
				return CTBool(value=False)
			return CTRef(name=val)
		if self._peek().type == TokenType.TRUE:
			self._advance()
			return CTBool(value=True)
		if self._peek().type == TokenType.FALSE:
			self._advance()
			return CTBool(value=False)
		if self._peek().type == TokenType.INT_LIT:
			return CTInt(value=int(self._advance().value))
		if self._peek().type == TokenType.FLOAT_LIT:
			return CTFloat(value=float(self._advance().value))
		if self._peek().type == TokenType.STRING_LIT:
			return CTString(value=self._advance().value.strip('"'))
		if self._peek().type == TokenType.MINUS:
			self._advance()
			inner = self._parse_ct_value()
			return CTUnary(op="-", operand=inner)
		if self._peek().type == TokenType.META_DOLLAR:
			self._advance()
			name = self._advance().value
			return CTRef(name=name)
		self._error(f"expected compile-time value, got {self._peek().type.name}")

	def _parse_ct_expr(self):
		return self._parse_ct_or()

	def _parse_ct_or(self):
		left = self._parse_ct_and()
		while self._peek().type == TokenType.OR:
			self._advance()
			right = self._parse_ct_and()
			left = CTBinary(op="||", left=left, right=right)
		return left

	def _parse_ct_and(self):
		left = self._parse_ct_equality()
		while self._peek().type == TokenType.AND:
			self._advance()
			right = self._parse_ct_equality()
			left = CTBinary(op="&&", left=left, right=right)
		return left

	def _parse_ct_equality(self):
		left = self._parse_ct_comparison()
		while self._peek().type in (TokenType.EQ, TokenType.NEQ):
			op = "==" if self._peek().type == TokenType.EQ else "!="
			self._advance()
			right = self._parse_ct_comparison()
			left = CTBinary(op=op, left=left, right=right)
		return left

	def _parse_ct_comparison(self):
		left = self._parse_ct_bitwise_or()
		while self._peek().type in (TokenType.LT, TokenType.GT, TokenType.LEQ, TokenType.GEQ):
			op_map = {TokenType.LT: "<", TokenType.GT: ">", TokenType.LEQ: "<=", TokenType.GEQ: ">="}
			op = op_map[self._peek().type]
			self._advance()
			right = self._parse_ct_bitwise_or()
			left = CTBinary(op=op, left=left, right=right)
		return left

	def _parse_ct_bitwise_or(self):
		left = self._parse_ct_bitwise_xor()
		while self._peek().type == TokenType.PIPE:
			self._advance()
			right = self._parse_ct_bitwise_xor()
			left = CTBinary(op="|", left=left, right=right)
		return left

	def _parse_ct_bitwise_xor(self):
		left = self._parse_ct_bitwise_and()
		while self._peek().type == TokenType.CARET:
			self._advance()
			right = self._parse_ct_bitwise_and()
			left = CTBinary(op="^", left=left, right=right)
		return left

	def _parse_ct_bitwise_and(self):
		left = self._parse_ct_shift()
		while self._peek().type == TokenType.AMP:
			self._advance()
			right = self._parse_ct_shift()
			left = CTBinary(op="&", left=left, right=right)
		return left

	def _parse_ct_shift(self):
		left = self._parse_ct_additive()
		while self._peek().type in (TokenType.SHL, TokenType.SHR):
			op = "<<" if self._peek().type == TokenType.SHL else ">>"
			self._advance()
			right = self._parse_ct_additive()
			left = CTBinary(op=op, left=left, right=right)
		return left

	def _parse_ct_additive(self):
		left = self._parse_ct_multiplicative()
		while self._peek().type in (TokenType.PLUS, TokenType.MINUS):
			op = "+" if self._peek().type == TokenType.PLUS else "-"
			self._advance()
			right = self._parse_ct_multiplicative()
			left = CTBinary(op=op, left=left, right=right)
		return left

	def _parse_ct_multiplicative(self):
		left = self._parse_ct_unary()
		while self._peek().type in (TokenType.STAR, TokenType.SLASH, TokenType.PERCENT):
			op_map = {TokenType.STAR: "*", TokenType.SLASH: "/", TokenType.PERCENT: "%"}
			op = op_map[self._peek().type]
			self._advance()
			right = self._parse_ct_unary()
			left = CTBinary(op=op, left=left, right=right)
		return left

	def _parse_ct_unary(self):
		if self._peek().type in (TokenType.NOT, TokenType.TILDE, TokenType.MINUS):
			op_map = {TokenType.NOT: "!", TokenType.TILDE: "~", TokenType.MINUS: "-"}
			op = op_map[self._peek().type]
			self._advance()
			operand = self._parse_ct_unary()
			return CTUnary(op=op, operand=operand)
		return self._parse_ct_primary()

	def _parse_ct_primary(self):
		if self._peek().type == TokenType.LBRACE:
			self._advance()
			expr = self._parse_ct_expr()
			if self._peek().type == TokenType.RBRACE:
				self._advance()
			return expr
		if self._peek().type == TokenType.INT_LIT:
			return CTInt(value=int(self._advance().value))
		if self._peek().type == TokenType.FLOAT_LIT:
			return CTFloat(value=float(self._advance().value))
		if self._peek().type == TokenType.STRING_LIT:
			return CTString(value=self._advance().value.strip('"'))
		if self._peek().type == TokenType.TRUE:
			self._advance()
			return CTBool(value=True)
		if self._peek().type == TokenType.FALSE:
			self._advance()
			return CTBool(value=False)
		if self._peek().type == TokenType.IDENT:
			val = self._advance().value
			if val == "true":
				return CTBool(value=True)
			if val == "false":
				return CTBool(value=False)
			if val == "if":
				return self._parse_ct_if()
			return CTRef(name=val)
		if self._peek().type == TokenType.MINUS:
			self._advance()
			inner = self._parse_ct_primary()
			return CTUnary(op="-", operand=inner)
		if self._peek().type == TokenType.META_DOLLAR:
			self._advance()
			name = self._advance().value
			return CTRef(name=name)
		self._error(f"expected compile-time expression, got {self._peek().type.name} ('{self._peek().value}')")

	def _parse_ct_if(self):
		cond = self._parse_ct_expr()
		if self._peek().type == TokenType.IDENT and self._peek().value == "then":
			self._advance()
		then_branch = self._parse_ct_expr()
		else_branch = CTInt(value=0)
		if self._peek().type == TokenType.IDENT and self._peek().value == "else":
			self._advance()
			else_branch = self._parse_ct_expr()
		return CTIf(cond=cond, then_branch=then_branch, else_branch=else_branch)
