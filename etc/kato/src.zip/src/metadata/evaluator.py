from dataclasses import dataclass
from typing import Optional


class CTEvalError(Exception):

	def __init__(self, msg):
		self.msg = msg
		super().__init__(f"compile-time error: {msg}")


class CTEvaluator:
	"""Evaluates compile-time expressions from the metadata DSL."""

	def __init__(self, let_bindings: dict, meta_vars: dict = None):
		self.let_bindings = let_bindings
		self.meta_vars = meta_vars or {}

	def eval(self, expr) -> object:
		if expr is None:
			return None

		from src.metadata.nodes import (
			CTInt, CTFloat, CTString, CTBool,
			CTRef, CTBinary, CTUnary, CTIf,
		)

		if isinstance(expr, CTInt):
			return expr.value
		if isinstance(expr, CTFloat):
			return expr.value
		if isinstance(expr, CTString):
			return expr.value
		if isinstance(expr, CTBool):
			return expr.value
		if isinstance(expr, CTRef):
			if expr.name in self.let_bindings:
				return self.eval(self.let_bindings[expr.name])
			if expr.name in self.meta_vars:
				return self.meta_vars[expr.name]
			raise CTEvalError(f"undefined compile-time variable: {expr.name}")
		if isinstance(expr, CTUnary):
			val = self.eval(expr.operand)
			if expr.op == "-":
				return -val
			if expr.op == "!":
				return not val
			if expr.op == "~":
				return ~val
			raise CTEvalError(f"unknown unary op: {expr.op}")
		if isinstance(expr, CTBinary):
			left = self.eval(expr.left)
			right = self.eval(expr.right)
			return self._binary(expr.op, left, right)
		if isinstance(expr, CTIf):
			cond = self.eval(expr.cond)
			if cond:
				return self.eval(expr.then_branch)
			else:
				return self.eval(expr.else_branch)
		raise CTEvalError(f"cannot evaluate compile-time expression: {type(expr).__name__}")

	def _binary(self, op, left, right):
		if op == "+":
			return left + right
		if op == "-":
			return left - right
		if op == "*":
			return left * right
		if op == "/":
			if right == 0:
				raise CTEvalError("division by zero in compile-time expression")
			return left // right if isinstance(left, int) and isinstance(right, int) else left / right
		if op == "%":
			if right == 0:
				raise CTEvalError("modulo by zero in compile-time expression")
			return left % right
		if op == "<<":
			return left << right
		if op == ">>":
			return left >> right
		if op == "&":
			return left & right
		if op == "|":
			return left | right
		if op == "^":
			return left ^ right
		if op == "==":
			return left == right
		if op == "!=":
			return left != right
		if op == "<":
			return left < right
		if op == ">":
			return left > right
		if op == "<=":
			return left <= right
		if op == ">=":
			return left >= right
		if op == "&&":
			return left and right
		if op == "||":
			return left or right
		raise CTEvalError(f"unknown binary op: {op}")

	def eval_int(self, expr) -> int:
		val = self.eval(expr)
		if isinstance(val, bool):
			return 1 if val else 0
		if isinstance(val, (int, float)):
			return int(val)
		raise CTEvalError(f"expected integer, got {type(val).__name__}")

	def eval_bool(self, expr) -> bool:
		val = self.eval(expr)
		if isinstance(val, bool):
			return val
		if isinstance(val, int):
			return val != 0
		raise CTEvalError(f"expected boolean, got {type(val).__name__}")

	def eval_string(self, expr) -> str:
		val = self.eval(expr)
		if isinstance(val, str):
			return val
		raise CTEvalError(f"expected string, got {type(val).__name__}")

	def resolve_properties(self, type_def) -> dict:
		"""Resolve all CTExpr properties of a TypeDef to concrete values."""
		resolved = {}
		for key, expr in type_def.properties.items():
			try:
				resolved[key] = self.eval(expr)
			except CTEvalError:
				resolved[key] = None
		for key, expr in type_def.field_arrays.items():
			try:
				resolved[f"_array_{key}"] = self.eval(expr)
			except CTEvalError:
				resolved[f"_array_{key}"] = None
		return resolved
