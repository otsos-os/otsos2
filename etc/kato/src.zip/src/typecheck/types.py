from typing import Dict, Optional, Set
from dataclasses import dataclass

from src.parser.ast import (
	TypeRef, Literal, Identifier, BinaryOp, UnaryOp,
	IndexAccess, FieldAccess, Call,
)
from src.metadata.nodes import Metadata, TypeDef


PRIMITIVES = {"int", "int64", "uint", "uint64", "float", "double", "char", "bool", "void"}
INT_TYPES = {"int", "int64", "uint", "uint64"}
FLOAT_TYPES = {"float", "double"}
NUMERIC_TYPES = INT_TYPES | FLOAT_TYPES


@dataclass
class TypeInfo:
	name: str = "unknown"
	is_pointer: bool = False
	is_array: bool = False
	is_mut: bool = False
	is_unknown: bool = True

	@staticmethod
	def unknown():
		return TypeInfo(is_unknown=True)

	@staticmethod
	def void():
		return TypeInfo(name="void", is_unknown=False)

	@staticmethod
	def make(name, **kwargs):
		return TypeInfo(name=name, is_unknown=False, **kwargs)

	def is_numeric(self):
		return self.name in NUMERIC_TYPES

	def is_int(self):
		return self.name in INT_TYPES

	def is_float(self):
		return self.name in FLOAT_TYPES

	def is_bool(self):
		return self.name == "bool"

	def is_void(self):
		return self.name == "void"

	def is_struct(self):
		return self.name not in PRIMITIVES and not self.is_pointer

	def compatible_with(self, other) -> bool:
		if self.is_unknown or other.is_unknown:
			return True
		if self.name == other.name and self.is_pointer == other.is_pointer:
			return True
		if self.is_numeric and other.is_numeric:
			if self.is_pointer or other.is_pointer:
				return False
			return True
		if self.is_pointer and other.is_int:
			return False
		return False

	def can_coerce_to(self, other) -> bool:
		if self.is_unknown or other.is_unknown:
			return True
		if self.compatible_with(other):
			return True
		if self.is_int and other.is_float:
			return True
		if self.is_int and other.is_int:
			return True
		return False

	def coerce_priority(self) -> int:
		if self.is_float:
			return 10 if self.name == "double" else 9
		if self.is_int:
			return 5 if self.name in ("int64", "uint64") else 4
		if self.is_bool:
			return 2
		if self.is_pointer:
			return 1
		return 0


class TypeSystem:

	def __init__(self, meta: Optional[Metadata] = None):
		self.meta = meta
		self.struct_fields: Dict[str, Dict[str, TypeInfo]] = {}
		self.struct_arrays: Dict[str, Dict[str, str]] = {}
		self.struct_types: Dict[str, TypeDef] = {}
		self.enum_variants: Dict[str, Set[str]] = {}
		self.func_signatures: Dict[str, dict] = {}

	def register_struct(self, name, fields, type_def=None):
		self.struct_fields[name] = fields
		if type_def:
			self.struct_types[name] = type_def
			for fname, arr_expr in type_def.field_arrays.items():
				if name not in self.struct_arrays:
					self.struct_arrays[name] = {}
				self.struct_arrays[name][fname] = "array"

	def register_enum(self, name, variants):
		self.enum_variants[name] = set(variants)

	def register_func(self, name, params, return_type):
		self.func_signatures[name] = {
			"params": params,
			"return": return_type,
		}

	def is_type(self, name) -> bool:
		if name in PRIMITIVES:
			return True
		if name in self.struct_fields:
			return True
		if name in self.enum_variants:
			return True
		if self.meta and self.meta.get_type_def(name):
			return True
		return False

	def get_struct_field(self, struct_name, field_name) -> Optional[TypeInfo]:
		fields = self.struct_fields.get(struct_name)
		if fields:
			return fields.get(field_name)
		return None

	def has_struct_field(self, struct_name, field_name) -> bool:
		return self.get_struct_field(struct_name, field_name) is not None

	def get_func_sig(self, name) -> Optional[dict]:
		return self.func_signatures.get(name)

	def get_struct_capacity(self, struct_name, field_name) -> Optional[str]:
		if not self.meta:
			return None
		td = self.meta.get_type_def(struct_name)
		if td:
			arr = td.field_arrays.get(field_name)
			if arr is not None:
				from src.metadata.evaluator import CTEvaluator
				ev = CTEvaluator(self.meta.let_bindings)
				try:
					return str(ev.eval_int(arr))
				except Exception:
					return None
		return None

	def infer_literal(self, lit: Literal) -> TypeInfo:
		if lit.lit_type == "int":
			return TypeInfo.make("int")
		if lit.lit_type == "float":
			return TypeInfo.make("double")
		if lit.lit_type == "char":
			return TypeInfo.make("char")
		if lit.lit_type == "bool":
			return TypeInfo.make("bool")
		if lit.lit_type == "string":
			return TypeInfo.make("char", is_pointer=True)
		if lit.lit_type == "c_var":
			return TypeInfo.unknown()
		if lit.lit_type == "zero_init":
			return TypeInfo.unknown()
		if lit.lit_type == "struct_init":
			return TypeInfo.unknown()
		return TypeInfo.unknown()

	def infer_binary(self, op: str, left: TypeInfo, right: TypeInfo) -> TypeInfo:
		if left.is_unknown or right.is_unknown:
			return TypeInfo.unknown()

		if op in ("==", "!=", "<", ">", "<=", ">=", "&&", "||"):
			return TypeInfo.make("bool")

		if op in ("&", "|", "^", "<<", ">>"):
			if left.is_int and right.is_int:
				return left
			return TypeInfo.unknown()

		if op in ("+", "-", "*", "/", "%", "//"):
			if left.is_numeric and right.is_numeric:
				if left.is_float or right.is_float:
					if left.name == "double" or right.name == "double":
						return TypeInfo.make("double")
					return TypeInfo.make("float")
				return left
			return TypeInfo.unknown()

		return TypeInfo.unknown()

	def infer_unary(self, op: str, operand: TypeInfo) -> TypeInfo:
		if operand.is_unknown:
			return TypeInfo.unknown()
		if op == "!":
			return TypeInfo.make("bool")
		if op == "~":
			if operand.is_int:
				return operand
			return TypeInfo.unknown()
		if op == "-":
			if operand.is_numeric:
				return operand
			return TypeInfo.unknown()
		if op == "&":
			return TypeInfo(name=operand.name, is_pointer=True, is_unknown=False)
		if op == "*":
			if operand.is_pointer:
				return TypeInfo.make(operand.name)
			return TypeInfo.unknown()
		if op in ("++", "--"):
			if operand.is_int:
				return operand
			return TypeInfo.unknown()
		return TypeInfo.unknown()

	def types_compatible(self, a: TypeInfo, b: TypeInfo) -> bool:
		return a.compatible_with(b)

	def can_assign(self, target: TypeInfo, value: TypeInfo) -> bool:
		if target.is_unknown or value.is_unknown:
			return True
		if target.compatible_with(value):
			return True
		if value.can_coerce_to(target):
			return True
		return False

	def is_valid_array_index(self, index_type: TypeInfo) -> bool:
		if index_type.is_unknown:
			return True
		return index_type.is_int
