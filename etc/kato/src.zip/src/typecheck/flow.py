from typing import List, Optional

from src.parser.ast import (
	FuncDecl, IfExpr, WhileLoop, MapExpr, FoldExpr, FilterExpr,
	MatchExpr, MatchArm, ReturnStmt, BreakStmt, ContinueStmt,
	LetBinding, Assignment, BinaryOp, UnaryOp, Call, Identifier,
	Literal, IndexAccess, FieldAccess, Block,
)


class FlowAnalyzer:
	"""Control flow analysis: return paths, unreachable code, cyclomatic complexity."""

	def __init__(self, func: FuncDecl):
		self.func = func
		self.complexity = 1

	def analyze(self) -> dict:
		return {
			"complexity": self._compute_complexity(self.func.body),
			"all_paths_return": self._all_paths_return(self.func.body),
			"unreachable": self._find_unreachable(self.func.body),
			"return_count": self._count_returns(self.func.body),
			"has_infinite_loop": self._has_infinite_loop(self.func.body),
		}

	def _compute_complexity(self, stmts) -> int:
		complexity = 1
		for stmt in stmts:
			complexity += self._complexity_stmt(stmt)
		return complexity

	def _complexity_stmt(self, stmt) -> int:
		if isinstance(stmt, IfExpr):
			c = 1
			for s in stmt.then_body:
				c += self._complexity_stmt(s)
			if stmt.else_body:
				c += 1
				for s in stmt.else_body:
					c += self._complexity_stmt(s)
			return c
		if isinstance(stmt, WhileLoop):
			c = 1
			for s in stmt.body:
				c += self._complexity_stmt(s)
			return c
		if isinstance(stmt, MapExpr):
			c = 1
			if stmt.condition:
				c += 1
			for s in stmt.body:
				c += self._complexity_stmt(s)
			return c
		if isinstance(stmt, FoldExpr):
			c = 1
			if stmt.condition:
				c += 1
			for s in stmt.body:
				c += self._complexity_stmt(s)
			return c
		if isinstance(stmt, FilterExpr):
			return 1 if stmt.condition else 0
		if isinstance(stmt, MatchExpr):
			c = len(stmt.arms) - 1
			for arm in stmt.arms:
				for s in arm.body:
					c += self._complexity_stmt(s)
			return c
		if isinstance(stmt, BinaryOp):
			if stmt.op in ("&&", "||"):
				return 1
		return 0

	def _all_paths_return(self, stmts) -> bool:
		if not stmts:
			return False
		for i, stmt in enumerate(stmts):
			if isinstance(stmt, ReturnStmt):
				return True
			if isinstance(stmt, IfExpr):
				then_returns = self._all_paths_return(stmt.then_body)
				else_returns = self._all_paths_return(stmt.else_body) if stmt.else_body else False
				if then_returns and else_returns:
					return True
			if isinstance(stmt, WhileLoop):
				if self._is_always_true_cond(stmt.cond):
					if self._all_paths_return(stmt.body):
						return True
			if i == len(stmts) - 1:
				if isinstance(stmt, (Identifier, BinaryOp, UnaryOp, Call,
					IndexAccess, FieldAccess, Literal, FoldExpr)):
					return True
				if isinstance(stmt, IfExpr) and stmt.else_body:
					then_returns = self._all_paths_return(stmt.then_body)
					else_returns = self._all_paths_return(stmt.else_body)
					if then_returns and else_returns:
						return True
		return False

	def _find_unreachable(self, stmts) -> list:
		unreachable = []
		found_terminator = False
		for stmt in stmts:
			if found_terminator:
				unreachable.append(stmt)
				continue
			if isinstance(stmt, ReturnStmt):
				found_terminator = True
			elif isinstance(stmt, BreakStmt):
				found_terminator = True
			elif isinstance(stmt, ContinueStmt):
				found_terminator = True
			elif isinstance(stmt, IfExpr):
				unreachable.extend(self._find_unreachable(stmt.then_body))
				if stmt.else_body:
					unreachable.extend(self._find_unreachable(stmt.else_body))
			elif isinstance(stmt, WhileLoop):
				unreachable.extend(self._find_unreachable(stmt.body))
			elif isinstance(stmt, MatchExpr):
				for arm in stmt.arms:
					unreachable.extend(self._find_unreachable(arm.body))
		return unreachable

	def _count_returns(self, stmts) -> int:
		count = 0
		for stmt in stmts:
			if isinstance(stmt, ReturnStmt):
				count += 1
			elif isinstance(stmt, IfExpr):
				count += self._count_returns(stmt.then_body)
				if stmt.else_body:
					count += self._count_returns(stmt.else_body)
			elif isinstance(stmt, WhileLoop):
				count += self._count_returns(stmt.body)
			elif isinstance(stmt, MapExpr):
				count += self._count_returns(stmt.body)
			elif isinstance(stmt, FoldExpr):
				count += self._count_returns(stmt.body)
			elif isinstance(stmt, MatchExpr):
				for arm in stmt.arms:
					count += self._count_returns(arm.body)
		return count

	def _has_infinite_loop(self, stmts) -> bool:
		for stmt in stmts:
			if isinstance(stmt, WhileLoop):
				if self._is_always_true_cond(stmt.cond):
					has_break = self._has_break(stmt.body)
					if not has_break:
						return True
			if isinstance(stmt, IfExpr):
				if self._has_infinite_loop(stmt.then_body):
					return True
				if stmt.else_body and self._has_infinite_loop(stmt.else_body):
					return True
		return False

	def _has_break(self, stmts) -> bool:
		for stmt in stmts:
			if isinstance(stmt, BreakStmt):
				return True
			if isinstance(stmt, IfExpr):
				if self._has_break(stmt.then_body):
					return True
				if stmt.else_body and self._has_break(stmt.else_body):
					return True
		return False

	def _is_always_true_cond(self, cond) -> bool:
		if isinstance(cond, Literal):
			if cond.lit_type == "bool" and cond.value == "true":
				return True
			if cond.lit_type == "int" and cond.value == "1":
				return True
		return False

	def collect_used_variables(self, stmts) -> set:
		used = set()
		for stmt in stmts:
			self._collect_used_stmt(stmt, used)
		return used

	def _collect_used_stmt(self, node, used: set):
		if isinstance(node, Identifier):
			used.add(node.name)
		elif isinstance(node, BinaryOp):
			self._collect_used_stmt(node.left, used)
			self._collect_used_stmt(node.right, used)
		elif isinstance(node, UnaryOp):
			self._collect_used_stmt(node.operand, used)
		elif isinstance(node, IndexAccess):
			self._collect_used_stmt(node.target, used)
			self._collect_used_stmt(node.index, used)
		elif isinstance(node, FieldAccess):
			self._collect_used_stmt(node.target, used)
		elif isinstance(node, Call):
			for arg in node.args:
				self._collect_used_stmt(arg, used)
		elif isinstance(node, Assignment):
			self._collect_used_stmt(node.target, used)
			self._collect_used_stmt(node.value, used)
		elif isinstance(node, LetBinding):
			if node.value:
				self._collect_used_stmt(node.value, used)
		elif isinstance(node, IfExpr):
			self._collect_used_stmt(node.cond, used)
			for s in node.then_body:
				self._collect_used_stmt(s, used)
			if node.else_body:
				for s in node.else_body:
					self._collect_used_stmt(s, used)
		elif isinstance(node, WhileLoop):
			self._collect_used_stmt(node.cond, used)
			for s in node.body:
				self._collect_used_stmt(s, used)
		elif isinstance(node, MapExpr):
			self._collect_used_stmt(node.range.start, used)
			self._collect_used_stmt(node.range.end, used)
			if node.condition:
				self._collect_used_stmt(node.condition, used)
			for s in node.body:
				self._collect_used_stmt(s, used)
		elif isinstance(node, FoldExpr):
			self._collect_used_stmt(node.initial, used)
			self._collect_used_stmt(node.range.start, used)
			self._collect_used_stmt(node.range.end, used)
			if node.condition:
				self._collect_used_stmt(node.condition, used)
			for s in node.body:
				self._collect_used_stmt(s, used)
		elif isinstance(node, MatchExpr):
			self._collect_used_stmt(node.subject, used)
			for arm in node.arms:
				if not arm.is_wildcard and arm.pattern:
					self._collect_used_stmt(arm.pattern, used)
				for s in arm.body:
					self._collect_used_stmt(s, used)
		elif isinstance(node, ReturnStmt):
			if node.value:
				self._collect_used_stmt(node.value, used)
