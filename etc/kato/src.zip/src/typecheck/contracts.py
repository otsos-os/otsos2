from src.parser.ast import (
	Program, FuncDecl, Param, Assignment, Call, Identifier,
	FieldAccess, IndexAccess, UnaryOp, ReturnStmt,
	IfExpr, WhileLoop, MapExpr, FoldExpr, MatchExpr,
	BinaryOp, LetBinding, BreakStmt, ContinueStmt,
)
from src.metadata.nodes import Metadata, FuncContract
from src.util.errors import ErrorReporter
from src.typecheck.callgraph import CallGraph
from src.typecheck.flow import FlowAnalyzer


class ContractChecker:
	"""Enforces function contracts from the metadata DSL."""

	def __init__(self, program: Program, meta: Metadata, reporter: ErrorReporter, callgraph: CallGraph):
		self.program = program
		self.meta = meta
		self.reporter = reporter
		self.callgraph = callgraph

	def check(self):
		for func in self.program.functions:
			contract = self.meta.get_func_contract(func.name)
			if contract:
				self._check_contract(func, contract)

	def _check_contract(self, func: FuncDecl, contract: FuncContract):
		self._check_purity(func, contract)
		self._check_mutates(func, contract)
		self._check_recurses(func, contract)
		self._check_complexity(func, contract)
		self._check_allocates(func, contract)
		self._check_return_type(func, contract)
		self._check_arg_count(func, contract)

	def _check_purity(self, func: FuncDecl, contract: FuncContract):
		if contract.pure:
			for stmt in func.body:
				if self._has_mutation(stmt):
					self.reporter.error(
						f"function '{func.name}' declared pure but mutates state",
						func.line, func.col
					)
					break

	def _has_mutation(self, stmt) -> bool:
		if isinstance(stmt, Assignment):
			return True
		if isinstance(stmt, UnaryOp) and stmt.op in ("++", "--"):
			return True
		if isinstance(stmt, ReturnStmt):
			return False
		if isinstance(stmt, Call):
			return False
		if isinstance(stmt, LetBinding):
			return False
		if isinstance(stmt, IfExpr):
			for s in stmt.then_body:
				if self._has_mutation(s):
					return True
			if stmt.else_body:
				for s in stmt.else_body:
					if self._has_mutation(s):
						return True
		if isinstance(stmt, WhileLoop):
			for s in stmt.body:
				if self._has_mutation(s):
					return True
		if isinstance(stmt, MapExpr):
			for s in stmt.body:
				if self._has_mutation(s):
					return True
		if isinstance(stmt, FoldExpr):
			for s in stmt.body:
				if self._has_mutation(s):
					return True
		return False

	def _check_mutates(self, func: FuncDecl, contract: FuncContract):
		param_names = set(p.name for p in func.params)
		mutated = set()
		self._collect_mutated(func.body, mutated)

		declared = set(contract.mutates)

		for m in mutated:
			if m not in param_names:
				continue
			if m not in declared:
				is_mut_param = False
				for p in func.params:
					if p.name == m and (p.is_mut or p.type_ref.is_mut):
						is_mut_param = True
						break
				if not is_mut_param:
					self.reporter.warning(
						f"function '{func.name}' mutates parameter '{m}' but it is not in mutates contract",
						func.line, func.col
					)

	def _collect_mutated(self, stmts, mutated: set):
		for stmt in stmts:
			self._collect_mutated_stmt(stmt, mutated)

	def _collect_mutated_stmt(self, stmt, mutated: set):
		if isinstance(stmt, Assignment):
			if isinstance(stmt.target, Identifier):
				mutated.add(stmt.target.name)
			elif isinstance(stmt.target, FieldAccess):
				if isinstance(stmt.target.target, Identifier):
					mutated.add(stmt.target.target.name)
			elif isinstance(stmt.target, IndexAccess):
				if isinstance(stmt.target.target, Identifier):
					mutated.add(stmt.target.target.name)
				elif isinstance(stmt.target.target, FieldAccess):
					if isinstance(stmt.target.target.target, Identifier):
						mutated.add(stmt.target.target.target.name)
		elif isinstance(stmt, UnaryOp) and stmt.op in ("++", "--"):
			if isinstance(stmt.operand, Identifier):
				mutated.add(stmt.operand.name)
		elif isinstance(stmt, Call):
			for arg in stmt.args:
				if isinstance(arg, UnaryOp) and arg.op == "&":
					if isinstance(arg.operand, Identifier):
						mutated.add(arg.operand.name)
		elif isinstance(stmt, ReturnStmt):
			if stmt.value and isinstance(stmt.value, UnaryOp) and stmt.value.op == "&":
				if isinstance(stmt.value.operand, Identifier):
					mutated.add(stmt.value.operand.name)
		elif isinstance(stmt, IfExpr):
			self._collect_mutated(stmt.then_body, mutated)
			if stmt.else_body:
				self._collect_mutated(stmt.else_body, mutated)
		elif isinstance(stmt, Call):
			for arg in stmt.args:
				if isinstance(arg, UnaryOp) and arg.op == "&":
					if isinstance(arg.operand, Identifier):
						mutated.add(arg.operand.name)

	def _check_recurses(self, func: FuncDecl, contract: FuncContract):
		if not contract.recurses:
			if self.callgraph.is_recursive(func.name):
				self.reporter.error(
					f"function '{func.name}' recurses but contract declares recurses: false",
					func.line, func.col
				)

	def _check_complexity(self, func: FuncDecl, contract: FuncContract):
		if contract.complexity_max > 0:
			flow = FlowAnalyzer(func)
			result = flow.analyze()
			if result["complexity"] > contract.complexity_max:
				self.reporter.error(
					f"function '{func.name}' has cyclomatic complexity {result['complexity']}, "
					f"exceeds contract max {contract.complexity_max}",
					func.line, func.col
				)

	def _check_allocates(self, func: FuncDecl, contract: FuncContract):
		if not contract.allocates:
			alloc_funcs = {"malloc", "calloc", "realloc", "free", "alloca"}
			found = []
			self._find_alloc_calls(func.body, alloc_funcs, found)
			for f in found:
				self.reporter.error(
					f"function '{func.name}' calls '{f}' but contract declares allocates: false",
					func.line, func.col
				)

	def _find_alloc_calls(self, stmts, alloc_funcs, found: list):
		for stmt in stmts:
			if isinstance(stmt, Call) and stmt.is_c_call:
				if stmt.name in alloc_funcs:
					found.append(stmt.name)
				for arg in stmt.args:
					if isinstance(arg, Call) and arg.is_c_call and arg.name in alloc_funcs:
						found.append(arg.name)
			if isinstance(stmt, IfExpr):
				self._find_alloc_calls(stmt.then_body, alloc_funcs, found)
				if stmt.else_body:
					self._find_alloc_calls(stmt.else_body, alloc_funcs, found)
			if isinstance(stmt, ReturnStmt) and stmt.value:
				if isinstance(stmt.value, Call) and stmt.value.is_c_call and stmt.value.name in alloc_funcs:
					found.append(stmt.value.name)

	def _check_return_type(self, func: FuncDecl, contract: FuncContract):
		if contract.returns != "void":
			flow = FlowAnalyzer(func)
			result = flow.analyze()
			if not result["all_paths_return"]:
				self.reporter.error(
					f"function '{func.name}' must return {contract.returns} on all paths, "
					f"but some paths fall through without return",
					func.line, func.col
				)

	def _check_arg_count(self, func: FuncDecl, contract: FuncContract):
		expected = len(contract.arg_order)
		actual = len(func.params)
		if expected != actual:
			self.reporter.error(
				f"function '{func.name}' has {actual} parameters but contract declares {expected}",
				func.line, func.col
			)
