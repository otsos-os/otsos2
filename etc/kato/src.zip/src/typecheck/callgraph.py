from typing import Dict, List, Set, Optional
from collections import defaultdict

from src.parser.ast import (
	Program, FuncDecl, Call, Identifier, Assignment,
	IndexAccess, FieldAccess, BinaryOp, UnaryOp, IfExpr,
	WhileLoop, MapExpr, FoldExpr, FilterExpr, MatchExpr, MatchArm,
	ReturnStmt, LetBinding, Literal,
)


class CallGraph:

	def __init__(self, program: Program):
		self.program = program
		self.func_table: Dict[str, FuncDecl] = {}
		self.edges: Dict[str, Set[str]] = defaultdict(set)
		self.recursive_funcs: Set[str] = set()
		self.mutually_recursive: List[Set[str]] = []

		for f in program.functions:
			self.func_table[f.name] = f

	def build(self):
		for f in self.program.functions:
			callees = set()
			self._collect_calls(f.body, callees)
			self.edges[f.name] = callees

		self._detect_recursion()

	def _collect_calls(self, stmts, callees: Set[str]):
		for stmt in stmts:
			self._collect_calls_stmt(stmt, callees)

	def _collect_calls_stmt(self, node, callees: Set[str]):
		if isinstance(node, Call):
			if not node.is_c_call:
				callees.add(node.name)
			for arg in node.args:
				self._collect_calls_expr(arg, callees)
		elif isinstance(node, Assignment):
			self._collect_calls_expr(node.value, callees)
			self._collect_calls_expr(node.target, callees)
		elif isinstance(node, IfExpr):
			self._collect_calls_expr(node.cond, callees)
			self._collect_calls(node.then_body, callees)
			if node.else_body:
				self._collect_calls(node.else_body, callees)
		elif isinstance(node, WhileLoop):
			self._collect_calls_expr(node.cond, callees)
			self._collect_calls(node.body, callees)
		elif isinstance(node, MapExpr):
			self._collect_calls_expr(node.range.start, callees)
			self._collect_calls_expr(node.range.end, callees)
			if node.condition:
				self._collect_calls_expr(node.condition, callees)
			self._collect_calls(node.body, callees)
		elif isinstance(node, FoldExpr):
			self._collect_calls_expr(node.initial, callees)
			self._collect_calls_expr(node.range.start, callees)
			self._collect_calls_expr(node.range.end, callees)
			if node.condition:
				self._collect_calls_expr(node.condition, callees)
			self._collect_calls(node.body, callees)
		elif isinstance(node, FilterExpr):
			self._collect_calls_expr(node.range.start, callees)
			self._collect_calls_expr(node.range.end, callees)
			if node.condition:
				self._collect_calls_expr(node.condition, callees)
		elif isinstance(node, MatchExpr):
			self._collect_calls_expr(node.subject, callees)
			for arm in node.arms:
				if not arm.is_wildcard and arm.pattern:
					self._collect_calls_expr(arm.pattern, callees)
				self._collect_calls(arm.body, callees)
		elif isinstance(node, ReturnStmt):
			if node.value:
				self._collect_calls_expr(node.value, callees)
		elif isinstance(node, LetBinding):
			if node.value:
				self._collect_calls_expr(node.value, callees)
		elif isinstance(node, BinaryOp):
			self._collect_calls_expr(node.left, callees)
			self._collect_calls_expr(node.right, callees)
		elif isinstance(node, UnaryOp):
			self._collect_calls_expr(node.operand, callees)
		elif isinstance(node, IndexAccess):
			self._collect_calls_expr(node.target, callees)
			self._collect_calls_expr(node.index, callees)
		elif isinstance(node, FieldAccess):
			self._collect_calls_expr(node.target, callees)

	def _collect_calls_expr(self, expr, callees: Set[str]):
		if isinstance(expr, Call):
			if not expr.is_c_call:
				callees.add(expr.name)
			for arg in expr.args:
				self._collect_calls_expr(arg, callees)
		elif isinstance(expr, BinaryOp):
			self._collect_calls_expr(expr.left, callees)
			self._collect_calls_expr(expr.right, callees)
		elif isinstance(expr, UnaryOp):
			self._collect_calls_expr(expr.operand, callees)
		elif isinstance(expr, IndexAccess):
			self._collect_calls_expr(expr.target, callees)
			self._collect_calls_expr(expr.index, callees)
		elif isinstance(expr, FieldAccess):
			self._collect_calls_expr(expr.target, callees)
		elif isinstance(expr, Assignment):
			self._collect_calls_expr(expr.value, callees)
		elif isinstance(expr, IfExpr):
			self._collect_calls_expr(expr.cond, callees)
			self._collect_calls(expr.then_body, callees)
			if expr.else_body:
				self._collect_calls(expr.else_body, callees)

	def _detect_recursion(self):
		for func_name in self.func_table:
			if self._is_recursive(func_name, func_name, set()):
				self.recursive_funcs.add(func_name)

		visited = set()
		for func_name in self.func_table:
			if func_name in visited:
				continue
			cycle = self._find_cycle(func_name, set(), [])
			if cycle:
				self.mutually_recursive.append(set(cycle))
				visited.update(cycle)

	def _is_recursive(self, start, target, visited) -> bool:
		if start in visited:
			return False
		visited.add(start)
		for callee in self.edges.get(start, set()):
			if callee == target:
				return True
			if self._is_recursive(callee, target, visited):
				return True
		return False

	def _find_cycle(self, start, visited, path) -> list:
		if start in visited:
			idx = path.index(start) if start in path else -1
			return path[idx:] if idx >= 0 else []
		visited.add(start)
		path.append(start)
		for callee in self.edges.get(start, set()):
			if callee in path:
				idx = path.index(callee)
				return path[idx:]
			result = self._find_cycle(callee, visited, list(path))
			if result:
				return result
		return []

	def is_recursive(self, func_name) -> bool:
		return func_name in self.recursive_funcs

	def get_callees(self, func_name) -> Set[str]:
		return self.edges.get(func_name, set())

	def get_callers(self, func_name) -> Set[str]:
		callers = set()
		for caller, callees in self.edges.items():
			if func_name in callees:
				callers.add(caller)
		return callers
