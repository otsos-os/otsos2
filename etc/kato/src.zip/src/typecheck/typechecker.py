from typing import Dict, List, Optional, Set
from dataclasses import dataclass

from src.parser.ast import (
	Program, FuncDecl, Param, StructDecl, StructField,
	EnumDecl, ConstDecl, TypeRef, Literal, Identifier,
	BinaryOp, UnaryOp, Assignment, IndexAccess, FieldAccess,
	Call, LetBinding, IfExpr, MatchExpr, MatchArm,
	MapExpr, FilterExpr, FoldExpr, WhileLoop, ReturnStmt,
	BreakStmt, ContinueStmt, Block,
)
from src.metadata.nodes import Metadata
from src.util.errors import ErrorReporter
from src.typecheck.types import TypeSystem, TypeInfo, PRIMITIVES
from src.typecheck.callgraph import CallGraph
from src.typecheck.flow import FlowAnalyzer
from src.typecheck.contracts import ContractChecker
from src.typecheck.safety import SafetyChecker


class TypeChecker:

	def __init__(self, program: Program, reporter: ErrorReporter):
		self.program = program
		self.reporter = reporter
		self.meta: Metadata = program.metadata
		self.ts = TypeSystem(meta=program.metadata)

		self.struct_table: Dict[str, StructDecl] = {}
		self.enum_table: Dict[str, EnumDecl] = {}
		self.const_table: Dict[str, ConstDecl] = {}
		self.func_table: Dict[str, FuncDecl] = {}

		self.scopes: List[Dict[str, TypeInfo]] = []
		self.current_func: Optional[FuncDecl] = None
		self.current_func_returns: bool = False

		self.callgraph = CallGraph(program)

	def check(self):
		for s in self.program.structs:
			self.struct_table[s.name] = s
		for e in self.program.enums:
			self.enum_table[e.name] = e
		for c in self.program.consts:
			self.const_table[c.name] = c
		for f in self.program.functions:
			self.func_table[f.name] = f

		for s in self.program.structs:
			self._check_struct(s)
		for e in self.program.enums:
			self._check_enum(e)
		for c in self.program.consts:
			self._check_const(c)

		self.callgraph.build()

		for f in self.program.functions:
			self._check_func(f)

		for f in self.program.functions:
			self._check_unreachable(f)

		for f in self.program.functions:
			self._check_unused_vars(f)

		if self.meta:
			contract_checker = ContractChecker(self.program, self.meta, self.reporter, self.callgraph)
			contract_checker.check()

		if self.meta and self.meta.is_safety():
			safety = SafetyChecker(self.program, self.meta, self.reporter)
			safety.check_all()

		self._check_start_function()

		return not self.reporter.has_errors()

	def _push_scope(self):
		self.scopes.append({})

	def _pop_scope(self):
		self.scopes.pop()

	def _declare(self, name, type_info: TypeInfo):
		self.scopes[-1][name] = type_info

	def _lookup(self, name) -> Optional[TypeInfo]:
		for scope in reversed(self.scopes):
			if name in scope:
				return scope[name]
		if name in self.const_table:
			return TypeInfo.make(self.const_table[name].type_ref.name)
		return None

	def _is_type(self, name) -> bool:
		return self.ts.is_type(name)

	def _check_struct(self, struct: StructDecl):
		seen = set()
		fields = {}
		type_def = self.meta.get_type_def(struct.name) if self.meta else None
		for field in struct.fields:
			if field.name in seen:
				self.reporter.error(
					f"duplicate field '{field.name}' in struct '{struct.name}'",
					struct.line, struct.col
				)
			seen.add(field.name)
			if not self._is_type(field.type_ref.name):
				self.reporter.error(
					f"unknown type '{field.type_ref.name}' in struct '{struct.name}' field '{field.name}'",
					field.line, field.col
				)
			fi = TypeInfo(
				name=field.type_ref.name,
				is_pointer=field.type_ref.is_pointer,
				is_array=field.type_ref.is_array,
				is_unknown=False,
			)
			fields[field.name] = fi
		self.ts.register_struct(struct.name, fields, type_def)

	def _check_enum(self, enum: EnumDecl):
		seen = set()
		variants = []
		for v in enum.variants:
			if v.name in seen:
				self.reporter.error(
					f"duplicate variant '{v.name}' in enum '{enum.name}'",
					v.line, v.col
				)
			seen.add(v.name)
			variants.append(v.name)
		self.ts.register_enum(enum.name, variants)

	def _check_const(self, const: ConstDecl):
		if not self._is_type(const.type_ref.name):
			self.reporter.error(
				f"unknown type '{const.type_ref.name}' in constant '{const.name}'",
				const.line, const.col
			)

	def _check_func(self, func: FuncDecl):
		self.current_func = func
		self.current_func_returns = False
		self._push_scope()

		params = []
		param_types = []
		for param in func.params:
			if not self._is_type(param.type_ref.name):
				self.reporter.error(
					f"unknown type '{param.type_ref.name}' in parameter '{param.name}' of function '{func.name}'",
					param.line, param.col
				)
			ti = TypeInfo(
				name=param.type_ref.name,
				is_pointer=param.type_ref.is_pointer,
				is_mut=param.is_mut or param.type_ref.is_mut,
				is_unknown=False,
			)
			self._declare(param.name, ti)
			params.append((param.name, ti))
			param_types.append(ti)

		if func.return_type and not self._is_type(func.return_type.name):
			self.reporter.error(
				f"unknown return type '{func.return_type.name}' in function '{func.name}'",
				func.line, func.col
			)

		ret_ti = TypeInfo(
			name=func.return_type.name if func.return_type else "void",
			is_pointer=func.return_type.is_pointer if func.return_type else False,
			is_unknown=False,
		)
		self.ts.register_func(func.name, param_types, ret_ti)

		for stmt in func.body:
			self._check_stmt(stmt)

		if not func.return_type or func.return_type.name == "void":
			pass
		else:
			flow = FlowAnalyzer(func)
			result = flow.analyze()
			if not result["all_paths_return"] and not self.current_func_returns:
				self.reporter.error(
					f"function '{func.name}' must return '{func.return_type.name}' on all paths, "
					f"but some paths fall through without a return",
					func.line, func.col
				)

		self._pop_scope()
		self.current_func = None

	def _check_stmt(self, stmt):
		if isinstance(stmt, LetBinding):
			self._check_let(stmt)
		elif isinstance(stmt, IfExpr):
			self._check_if(stmt)
		elif isinstance(stmt, MatchExpr):
			self._check_match(stmt)
		elif isinstance(stmt, MapExpr):
			self._check_map(stmt)
		elif isinstance(stmt, FilterExpr):
			self._check_filter(stmt)
		elif isinstance(stmt, FoldExpr):
			self._check_fold(stmt)
		elif isinstance(stmt, WhileLoop):
			self._check_while(stmt)
		elif isinstance(stmt, ReturnStmt):
			self._check_return(stmt)
		elif isinstance(stmt, BreakStmt):
			pass
		elif isinstance(stmt, ContinueStmt):
			pass
		elif isinstance(stmt, Assignment):
			self._check_assignment(stmt)
		else:
			self._check_expr(stmt)

	def _check_let(self, let: LetBinding):
		value_type = TypeInfo.unknown()
		if let.value:
			value_type = self._check_expr(let.value)

		declared_type = TypeInfo.unknown()
		if let.type_ref:
			if not self._is_type(let.type_ref.name):
				self.reporter.error(
					f"unknown type '{let.type_ref.name}' in let binding '{let.name}'",
					let.line, let.col
				)
			declared_type = TypeInfo(
				name=let.type_ref.name,
				is_pointer=let.type_ref.is_pointer,
				is_array=let.type_ref.is_array,
				is_mut=let.is_mut,
				is_unknown=False,
			)
		elif not value_type.is_unknown:
			declared_type = value_type
			declared_type.is_mut = let.is_mut
		else:
			declared_type = TypeInfo.make("int", is_mut=let.is_mut)

		if let.value and not declared_type.is_unknown and not value_type.is_unknown:
			if not self.ts.can_assign(declared_type, value_type):
				self.reporter.error(
					f"type mismatch in let binding '{let.name}': "
					f"cannot assign {value_type.name} to {declared_type.name}",
					let.line, let.col
				)

		for scope in self.scopes:
			if let.name in scope:
				self.reporter.warning(
					f"variable '{let.name}' shadows an earlier declaration",
					let.line, let.col
				)
				break

		self._declare(let.name, declared_type)

	def _check_if(self, if_expr: IfExpr):
		cond_type = self._check_expr(if_expr.cond)
		if not cond_type.is_unknown and not cond_type.is_bool:
			if cond_type.is_int:
				pass
			else:
				self.reporter.error(
					f"if condition must be bool or int, got {cond_type.name}",
					if_expr.line, if_expr.col
				)

		self._push_scope()
		for stmt in if_expr.then_body:
			self._check_stmt(stmt)
		self._pop_scope()

		if if_expr.else_body:
			self._push_scope()
			for stmt in if_expr.else_body:
				self._check_stmt(stmt)
			self._pop_scope()

	def _check_match(self, match: MatchExpr):
		subject_type = self._check_expr(match.subject)

		has_wildcard = any(arm.is_wildcard for arm in match.arms)
		if not has_wildcard:
			if subject_type.is_unknown:
				pass
			elif subject_type.name in self.enum_table:
				enum = self.enum_table[subject_type.name]
				covered = set()
				for arm in match.arms:
					if isinstance(arm.pattern, Identifier):
						covered.add(arm.pattern.name)
				missing = set(v.name for v in enum.variants) - covered
				if missing:
					self.reporter.warning(
						f"match on enum '{subject_type.name}' does not cover: {', '.join(sorted(missing))}",
						match.line, match.col
					)

		for arm in match.arms:
			if not arm.is_wildcard and arm.pattern:
				self._check_expr(arm.pattern)
			self._push_scope()
			for stmt in arm.body:
				self._check_stmt(stmt)
			self._pop_scope()

	def _check_map(self, map_expr: MapExpr):
		self._push_scope()
		self._declare(map_expr.index_var, TypeInfo.make("int"))

		start_type = self._check_expr(map_expr.range.start)
		end_type = self._check_expr(map_expr.range.end)

		if not start_type.is_int and not start_type.is_unknown:
			self.reporter.error(
				f"map range start must be int, got {start_type.name}",
				map_expr.line, map_expr.col
			)
		if not end_type.is_int and not end_type.is_unknown:
			self.reporter.error(
				f"map range end must be int, got {end_type.name}",
				map_expr.line, map_expr.col
			)

		if map_expr.condition:
			cond_type = self._check_expr(map_expr.condition)
			if not cond_type.is_unknown and not cond_type.is_bool:
				self.reporter.error(
					f"map where condition must be bool, got {cond_type.name}",
					map_expr.line, map_expr.col
				)

		for stmt in map_expr.body:
			self._check_stmt(stmt)
		self._pop_scope()

	def _check_filter(self, filter_expr: FilterExpr):
		self._push_scope()
		self._declare(filter_expr.index_var, TypeInfo.make("int"))
		self._check_expr(filter_expr.range.start)
		self._check_expr(filter_expr.range.end)
		if filter_expr.condition:
			self._check_expr(filter_expr.condition)
		self._pop_scope()

	def _check_fold(self, fold_expr: FoldExpr):
		self._check_expr(fold_expr.initial)
		self._push_scope()
		self._declare(fold_expr.index_var, TypeInfo.make("int"))

		init_type = self._check_expr(fold_expr.initial)
		if init_type.is_unknown:
			self._declare("acc", TypeInfo.make("float"))
		else:
			self._declare("acc", init_type)

		self._check_expr(fold_expr.range.start)
		self._check_expr(fold_expr.range.end)
		if fold_expr.condition:
			self._check_expr(fold_expr.condition)
		for stmt in fold_expr.body:
			self._check_stmt(stmt)
		self._pop_scope()

	def _check_while(self, while_loop: WhileLoop):
		cond_type = self._check_expr(while_loop.cond)
		if not cond_type.is_unknown and not cond_type.is_bool and not cond_type.is_int:
			self.reporter.error(
				f"while condition must be bool or int, got {cond_type.name}",
				while_loop.line, while_loop.col
			)
		self._push_scope()
		for stmt in while_loop.body:
			self._check_stmt(stmt)
		self._pop_scope()

	def _check_return(self, ret: ReturnStmt):
		self.current_func_returns = True
		if ret.value:
			value_type = self._check_expr(ret.value)
			if self.current_func and self.current_func.return_type:
				ret_type = TypeInfo(
					name=self.current_func.return_type.name,
					is_pointer=self.current_func.return_type.is_pointer,
					is_unknown=False,
				)
				if not ret_type.is_void and not value_type.is_unknown:
					if not self.ts.can_assign(ret_type, value_type):
						self.reporter.error(
							f"return type mismatch: cannot return {value_type.name} as {ret_type.name}",
							ret.line, ret.col
						)
		elif self.current_func and self.current_func.return_type:
			if not self.current_func.return_type.name == "void":
				self.reporter.error(
					f"function '{self.current_func.name}' must return a value",
					ret.line, ret.col
				)

	def _check_assignment(self, assign: Assignment):
		target_type = self._check_expr(assign.target)
		value_type = self._check_expr(assign.value)

		if isinstance(assign.target, Identifier):
			name = assign.target.name
			ti = self._lookup(name)
			if ti is None:
				self.reporter.error(
					f"assignment to undeclared variable '{name}'",
					assign.line, assign.col
				)
			elif not ti.is_mut:
				is_param = False
				if self.current_func:
					for p in self.current_func.params:
						if p.name == name and not p.is_mut and not p.type_ref.is_mut:
							is_param = True
							break
				if is_param:
					self.reporter.error(
						f"cannot mutate immutable parameter '{name}'",
						assign.line, assign.col
					)
				else:
					self.reporter.error(
						f"cannot mutate immutable variable '{name}'",
						assign.line, assign.col
					)

		if not target_type.is_unknown and not value_type.is_unknown:
			if not self.ts.can_assign(target_type, value_type):
				self.reporter.error(
					f"type mismatch in assignment: cannot assign {value_type.name} to {target_type.name}",
					assign.line, assign.col
				)

	def _check_expr(self, expr) -> TypeInfo:
		if isinstance(expr, Literal):
			return self.ts.infer_literal(expr)
		elif isinstance(expr, Identifier):
			ti = self._lookup(expr.name)
			if ti is None:
				if not (self.meta and self.meta.is_exported(expr.name)):
					if expr.name not in self.func_table:
						self.reporter.error(
							f"undeclared variable '{expr.name}'",
							expr.line, expr.col
						)
				return TypeInfo.unknown()
			return ti
		elif isinstance(expr, BinaryOp):
			return self._check_binary(expr)
		elif isinstance(expr, UnaryOp):
			return self._check_unary(expr)
		elif isinstance(expr, Assignment):
			self._check_assignment(expr)
			return TypeInfo.unknown()
		elif isinstance(expr, IndexAccess):
			return self._check_index(expr)
		elif isinstance(expr, FieldAccess):
			return self._check_field(expr)
		elif isinstance(expr, Call):
			return self._check_call(expr)
		elif isinstance(expr, IfExpr):
			self._check_if(expr)
			return TypeInfo.unknown()
		return TypeInfo.unknown()

	def _check_binary(self, binop: BinaryOp) -> TypeInfo:
		left_type = self._check_expr(binop.left)
		right_type = self._check_expr(binop.right)
		result = self.ts.infer_binary(binop.op, left_type, right_type)

		if binop.op in ("+", "-", "*", "/", "%", "//"):
			if not left_type.is_unknown and not right_type.is_unknown:
				if not left_type.is_numeric and not left_type.is_pointer:
					self.reporter.error(
						f"operator '{binop.op}' requires numeric or pointer operands, got {left_type.name}",
						binop.line, binop.col
					)
				if not right_type.is_numeric:
					self.reporter.error(
						f"operator '{binop.op}' requires numeric right operand, got {right_type.name}",
						binop.line, binop.col
					)
		elif binop.op in ("<<", ">>", "&", "|", "^"):
			if not left_type.is_unknown and not left_type.is_int:
				self.reporter.error(
					f"bitwise operator '{binop.op}' requires int, got {left_type.name}",
					binop.line, binop.col
				)
			if not right_type.is_unknown and not right_type.is_int:
				self.reporter.error(
					f"bitwise operator '{binop.op}' requires int, got {right_type.name}",
					binop.line, binop.col
				)
		elif binop.op in ("&&", "||"):
			if not left_type.is_unknown and not left_type.is_bool and not left_type.is_int:
				self.reporter.error(
					f"logical operator '{binop.op}' requires bool or int, got {left_type.name}",
					binop.line, binop.col
				)

		if binop.op in ("/", "%", "//"):
			if isinstance(binop.right, Literal):
				if binop.right.value == "0" and binop.right.lit_type in ("int", "float"):
					self.reporter.error(
						f"division by zero (constant)",
						binop.line, binop.col
					)

		return result

	def _check_unary(self, unop: UnaryOp) -> TypeInfo:
		operand_type = self._check_expr(unop.operand)
		result = self.ts.infer_unary(unop.op, operand_type)

		if unop.op == "*":
			if not operand_type.is_unknown and not operand_type.is_pointer:
				self.reporter.error(
					f"cannot dereference non-pointer type {operand_type.name}",
					unop.line, unop.col
				)
		elif unop.op == "&":
			if isinstance(unop.operand, Identifier):
				name = unop.operand.name
				ti = self._lookup(name)
				if ti and not ti.is_mut:
					pass
		elif unop.op in ("++", "--"):
			if not operand_type.is_unknown and not operand_type.is_int:
				self.reporter.error(
					f"operator '{unop.op}' requires int, got {operand_type.name}",
					unop.line, unop.col
				)
			if isinstance(unop.operand, Identifier):
				if not self._is_mut_name(unop.operand.name):
					self.reporter.error(
						f"cannot {unop.op} immutable variable '{unop.operand.name}'",
						unop.line, unop.col
					)

		return result

	def _is_mut_name(self, name) -> bool:
		for scope in reversed(self.scopes):
			if name in scope:
				return scope[name].is_mut
		return False

	def _check_index(self, idx: IndexAccess) -> TypeInfo:
		target_type = self._check_expr(idx.target)
		index_type = self._check_expr(idx.index)

		if not index_type.is_unknown and not self.ts.is_valid_array_index(index_type):
			self.reporter.error(
				f"array index must be int, got {index_type.name}",
				idx.line, idx.col
			)

		if isinstance(idx.index, Literal) and idx.index.lit_type == "int":
			idx_val = int(idx.index.value)
			if idx_val < 0:
				self.reporter.error(
					f"negative array index {idx_val}",
					idx.line, idx.col
				)

		if not target_type.is_unknown:
			if isinstance(idx.target, FieldAccess):
				if isinstance(idx.target.target, Identifier):
					var_name = idx.target.target.name
					field_name = idx.target.field
					ti = self._lookup(var_name)
					if ti and not ti.is_unknown:
						capacity = self.ts.get_struct_capacity(ti.name, field_name)
						if capacity and isinstance(idx.index, Literal) and idx.index.lit_type == "int":
							idx_val = int(idx.index.value)
							if idx_val >= int(capacity):
								self.reporter.error(
									f"array index {idx_val} out of bounds (capacity {capacity})",
									idx.line, idx.col
								)

		return TypeInfo.unknown()

	def _check_field(self, field: FieldAccess) -> TypeInfo:
		target_type = self._check_expr(field.target)

		if not target_type.is_unknown and target_type.name not in PRIMITIVES:
			fi = self.ts.get_struct_field(target_type.name, field.field)
			if fi is None:
				self.reporter.error(
					f"struct '{target_type.name}' has no field '{field.field}'",
					field.line, field.col
				)
				return TypeInfo.unknown()
			return fi
		elif not target_type.is_unknown:
			self.reporter.error(
				f"cannot access field '{field.field}' on non-struct type {target_type.name}",
				field.line, field.col
			)

		return TypeInfo.unknown()

	def _check_call(self, call: Call) -> TypeInfo:
		for arg in call.args:
			self._check_expr(arg)

		if call.is_c_call:
			return TypeInfo.unknown()

		if call.name not in self.func_table:
			if not (self.meta and self.meta.is_exported(call.name)):
				self.reporter.error(
					f"call to unknown function '{call.name}'",
					call.line, call.col
				)
			return TypeInfo.unknown()

		called_func = self.func_table[call.name]
		expected = len(called_func.params)
		actual = len(call.args)
		if expected != actual:
			self.reporter.error(
				f"function '{call.name}' expects {expected} arguments, got {actual}",
				call.line, call.col
			)

		sig = self.ts.get_func_sig(call.name)
		if sig:
			for i, arg in enumerate(call.args):
				if i < len(sig["params"]):
					param_type = sig["params"][i]
					arg_type = self._check_expr(arg)
					if not arg_type.is_unknown and not param_type.is_unknown:
						if not self.ts.can_assign(param_type, arg_type):
							self.reporter.error(
								f"argument {i+1} to '{call.name}': type mismatch, "
								f"expected {param_type.name}, got {arg_type.name}",
								call.line, call.col
							)
			return sig["return"]

		return TypeInfo.unknown()

	def _check_start_function(self):
		start_found = False
		if self.meta:
			for name, fc in self.meta.func_contracts.items():
				if fc.is_start():
					if name in self.func_table:
						f = self.func_table[name]
						if f.params:
							self.reporter.error(
								f"start function '{name}' must not have parameters",
								f.line, f.col
							)
					start_found = True
					break
		if not start_found:
			for f in self.program.functions:
				if f.name == "main":
					start_found = True
					break
		if not start_found:
			self.reporter.error("no start function (main) found")

	def _check_unreachable(self, func: FuncDecl):
		flow = FlowAnalyzer(func)
		result = flow.analyze()
		for stmt in result["unreachable"]:
			self.reporter.warning(
				f"unreachable code in function '{func.name}'",
				stmt.line, stmt.col
			)
		if result["has_infinite_loop"]:
			self.reporter.warning(
				f"function '{func.name}' has an infinite loop with no break",
				func.line, func.col
			)

	def _check_unused_vars(self, func: FuncDecl):
		declared = {}
		self._collect_declared(func.body, declared)

		flow = FlowAnalyzer(func)
		used = flow.collect_used_variables(func.body)

		for name, info in declared.items():
			if name not in used and info.get("is_param", False):
				self.reporter.warning(
					f"unused parameter '{name}' in function '{func.name}'",
					info.get("line", func.line), info.get("col", func.col)
				)
			elif name not in used and not info.get("is_param", False):
				if not name.startswith("__"):
					self.reporter.warning(
						f"unused variable '{name}' in function '{func.name}'",
						info.get("line", func.line), info.get("col", func.col)
					)

	def _collect_declared(self, stmts, declared: dict):
		for stmt in stmts:
			if isinstance(stmt, LetBinding):
				declared[stmt.name] = {
					"line": stmt.line,
					"col": stmt.col,
					"is_param": False,
				}
			elif isinstance(stmt, IfExpr):
				self._collect_declared(stmt.then_body, declared)
				if stmt.else_body:
					self._collect_declared(stmt.else_body, declared)
			elif isinstance(stmt, WhileLoop):
				self._collect_declared(stmt.body, declared)
			elif isinstance(stmt, MapExpr):
				self._collect_declared(stmt.body, declared)
			elif isinstance(stmt, FoldExpr):
				self._collect_declared(stmt.body, declared)
			elif isinstance(stmt, MatchExpr):
				for arm in stmt.arms:
					self._collect_declared(arm.body, declared)
		if self.current_func:
			for p in self.current_func.params:
				if p.name not in declared:
					declared[p.name] = {
						"line": p.line,
						"col": p.col,
						"is_param": True,
					}
