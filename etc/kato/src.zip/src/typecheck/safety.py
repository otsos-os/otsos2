from src.parser.ast import (
	Program, FuncDecl, IfExpr, WhileLoop, MapExpr, FoldExpr,
	FilterExpr, MatchExpr, MatchArm, ReturnStmt, BreakStmt,
	ContinueStmt, Assignment, Call, BinaryOp, UnaryOp, LetBinding,
	Identifier, Literal, IndexAccess, FieldAccess,
)
from src.metadata.nodes import Metadata
from src.util.errors import ErrorReporter
from src.typecheck.flow import FlowAnalyzer


FORBIDDEN_C_FUNCS_SAFETY = {
	"malloc", "calloc", "realloc", "free", "alloca",
	"setjmp", "longjmp",
}


class SafetyChecker:
	"""Enforces safety-mode-specific rules from DDPS Section 9."""

	def __init__(self, program: Program, meta: Metadata, reporter: ErrorReporter):
		self.program = program
		self.meta = meta
		self.reporter = reporter

	def check(self):
		for func in self.program.functions:
			self._check_func(func)

	def _check_func(self, func: FuncDecl):
		self._check_break_continue(func.body, func)
		self._check_forbidden_c_calls(func.body, func)
		self._check_return_count(func)
		self._check_complexity(func)

	def _check_break_continue(self, stmts, func: FuncDecl):
		for stmt in stmts:
			if isinstance(stmt, BreakStmt):
				self.reporter.error(
					f"'break' is forbidden in safety mode in function '{func.name}'",
					stmt.line, stmt.col
				)
			elif isinstance(stmt, ContinueStmt):
				self.reporter.error(
					f"'continue' is forbidden in safety mode in function '{func.name}'",
					stmt.line, stmt.col
				)
			elif isinstance(stmt, WhileLoop):
				self._check_break_continue(stmt.body, func)
			elif isinstance(stmt, IfExpr):
				self._check_break_continue(stmt.then_body, func)
				if stmt.else_body:
					self._check_break_continue(stmt.else_body, func)
			elif isinstance(stmt, MapExpr):
				self._check_break_continue(stmt.body, func)
			elif isinstance(stmt, FoldExpr):
				self._check_break_continue(stmt.body, func)
			elif isinstance(stmt, MatchExpr):
				for arm in stmt.arms:
					self._check_break_continue(arm.body, func)

	def _check_forbidden_c_calls(self, stmts, func: FuncDecl):
		for stmt in stmts:
			if isinstance(stmt, Call) and stmt.is_c_call:
				if stmt.name in FORBIDDEN_C_FUNCS_SAFETY:
					self.reporter.error(
						f"'{stmt.name}' is forbidden in safety mode in function '{func.name}'",
						stmt.line, stmt.col
					)
				for arg in stmt.args:
					if isinstance(arg, Call) and arg.is_c_call and arg.name in FORBIDDEN_C_FUNCS_SAFETY:
						self.reporter.error(
							f"'{arg.name}' is forbidden in safety mode in function '{func.name}'",
							arg.line, arg.col
						)
			if isinstance(stmt, IfExpr):
				self._check_forbidden_c_calls(stmt.then_body, func)
				if stmt.else_body:
					self._check_forbidden_c_calls(stmt.else_body, func)
			if isinstance(stmt, WhileLoop):
				self._check_forbidden_c_calls(stmt.body, func)
			if isinstance(stmt, ReturnStmt) and stmt.value:
				if isinstance(stmt.value, Call) and stmt.value.is_c_call:
					if stmt.value.name in FORBIDDEN_C_FUNCS_SAFETY:
						self.reporter.error(
							f"'{stmt.value.name}' is forbidden in safety mode in function '{func.name}'",
							stmt.value.line, stmt.value.col
						)
			if isinstance(stmt, LetBinding) and stmt.value:
				if isinstance(stmt.value, Call) and stmt.value.is_c_call:
					if stmt.value.name in FORBIDDEN_C_FUNCS_SAFETY:
						self.reporter.error(
							f"'{stmt.value.name}' is forbidden in safety mode in function '{func.name}'",
							stmt.value.line, stmt.value.col
						)

	def _check_return_count(self, func: FuncDecl):
		flow = FlowAnalyzer(func)
		result = flow.analyze()
		if result["return_count"] > 1:
			self.reporter.warning(
				f"function '{func.name}' has {result['return_count']} return statements "
				f"(safety mode prefers single exit via goto cleanup)",
				func.line, func.col
			)

	def _check_complexity(self, func: FuncDecl):
		max_cx = self.meta.complexity.max_complexity
		if max_cx <= 0:
			max_cx = 10
		flow = FlowAnalyzer(func)
		result = flow.analyze()
		if result["complexity"] > max_cx:
			self.reporter.error(
				f"function '{func.name}' has cyclomatic complexity {result['complexity']}, "
				f"exceeds safety limit {max_cx}",
				func.line, func.col
			)

	def _check_unreachable(self, func: FuncDecl):
		flow = FlowAnalyzer(func)
		result = flow.analyze()
		for stmt in result["unreachable"]:
			self.reporter.warning(
				f"unreachable code in function '{func.name}'",
				stmt.line, stmt.col
			)

	def _check_division_by_zero(self, stmts, func: FuncDecl):
		for stmt in stmts:
			if isinstance(stmt, BinaryOp) and stmt.op in ("/", "%", "//"):
				if isinstance(stmt.right, Literal):
					if stmt.right.lit_type in ("int", "float") and stmt.right.value == "0":
						self.reporter.error(
							f"division by zero (constant) in function '{func.name}'",
							stmt.line, stmt.col
						)
			if isinstance(stmt, IfExpr):
				self._check_division_by_zero(stmt.then_body, func)
				if stmt.else_body:
					self._check_division_by_zero(stmt.else_body, func)
			if isinstance(stmt, WhileLoop):
				self._check_division_by_zero(stmt.body, func)
			if isinstance(stmt, LetBinding) and stmt.value:
				if isinstance(stmt.value, BinaryOp) and stmt.value.op in ("/", "%", "//"):
					if isinstance(stmt.value.right, Literal):
						if stmt.value.right.lit_type in ("int", "float") and stmt.value.right.value == "0":
							self.reporter.error(
								f"division by zero (constant) in function '{func.name}'",
								stmt.value.line, stmt.value.col
							)
			if isinstance(stmt, ReturnStmt) and stmt.value:
				if isinstance(stmt.value, BinaryOp) and stmt.value.op in ("/", "%", "//"):
					if isinstance(stmt.value.right, Literal):
						if stmt.value.right.lit_type in ("int", "float") and stmt.value.right.value == "0":
							self.reporter.error(
								f"division by zero (constant) in function '{func.name}'",
								stmt.value.line, stmt.value.col
							)
			if isinstance(stmt, Assignment):
				if isinstance(stmt.value, BinaryOp) and stmt.value.op in ("/", "%", "//"):
					if isinstance(stmt.value.right, Literal):
						if stmt.value.right.lit_type in ("int", "float") and stmt.value.right.value == "0":
							self.reporter.error(
								f"division by zero (constant) in function '{func.name}'",
								stmt.value.line, stmt.value.col
							)

	def check_all(self):
		for func in self.program.functions:
			self._check_func(func)
			self._check_unreachable(func)
			self._check_division_by_zero(func.body, func)
