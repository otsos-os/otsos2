import os
from typing import List, Optional

from src.lexer.lexer import Lexer
from src.lexer.tokens import TokenType
from src.metadata.parser import MetadataParser
from src.metadata.nodes import Metadata, BoundsDirective, OverflowDirective, NullCheckDirective, DivCheckDirective, RangeCheckDirective, InitDirective, AllocDirective, ThreadDirective, ComplexityDirective, PanicDirective
from src.metadata.evaluator import CTEvaluator, CTEvalError
from src.parser.parser import Parser
from src.parser.ast import Program
from src.typecheck.typechecker import TypeChecker
from src.codegen.speed import SpeedCodeGen
from src.codegen.safety import SafetyCodeGen
from src.util.errors import ErrorReporter


def apply_mode_defaults(meta: Metadata):
	if meta.is_safety():
		if meta.bounds.mode == "none":
			meta.bounds = BoundsDirective(mode="static")
		if meta.overflow.mode == "unchecked":
			meta.overflow = OverflowDirective(mode="checked")
		if meta.null_check.mode == "never":
			meta.null_check = NullCheckDirective(mode="always")
		if meta.div_check.mode == "never":
			meta.div_check = DivCheckDirective(mode="always")
		if meta.range_check.mode == "never":
			meta.range_check = RangeCheckDirective(mode="always")
		if meta.init.mode == "none":
			meta.init = InitDirective(mode="zero")
		if meta.alloc.strategy == "dynamic":
			meta.alloc = AllocDirective(strategy="static")
		if meta.thread.mode == "single":
			meta.thread = ThreadDirective(mode="single")
		if meta.complexity.max_complexity == 0:
			meta.complexity = ComplexityDirective(max_complexity=10)
		if meta.panic.mode == "halt":
			meta.panic = PanicDirective(mode="halt")


class Compiler:

	def __init__(self):
		self.reporter = ErrorReporter()

	def compile_file(self, filepath: str, output_dir: str = "build") -> Optional[str]:
		if not os.path.exists(filepath):
			print(f"error: file not found: {filepath}")
			return None

		with open(filepath, "r", encoding="utf-8") as f:
			source = f.read()

		return self.compile_source(source, filepath, output_dir)

	def compile_source(self, source: str, filename: str, output_dir: str = "build") -> Optional[str]:
		try:
			lexer = Lexer(source, filename)
			tokens = lexer.tokenize()
		except Exception as e:
			print(f"lex error: {e}")
			return None

		meta_tokens = []
		code_tokens = []
		in_meta = False

		i = 0
		while i < len(tokens):
			tok = tokens[i]
			if tok.type == TokenType.META_START:
				in_meta = True
				meta_tokens.append(tok)
				i += 1
				continue
			if tok.type == TokenType.META_END:
				in_meta = False
				meta_tokens.append(tok)
				i += 1
				continue
			if in_meta:
				meta_tokens.append(tok)
			else:
				code_tokens.append(tok)
			i += 1

		code_tokens.append(tokens[-1])

		metadata = Metadata()
		if meta_tokens:
			try:
				meta_parser = MetadataParser(meta_tokens)
				metadata = meta_parser.parse()
			except Exception as e:
				print(f"metadata error: {e}")
				return None

		try:
			meta_vars = {
				"mode": metadata.mode,
				"bounds": metadata.bounds.mode,
				"overflow": metadata.overflow.mode,
				"null_check": metadata.null_check.mode,
				"div_check": metadata.div_check.mode,
				"range_check": metadata.range_check.mode,
				"alloc": metadata.alloc.strategy,
				"panic": metadata.panic.mode,
				"init": metadata.init.mode,
			}
			evaluator = CTEvaluator(metadata.let_bindings, meta_vars=meta_vars)
			for assert_stmt in metadata.asserts:
				if not evaluator.eval_bool(assert_stmt.expr):
					print(f"compile-time error: assertion failed")
					return None
		except CTEvalError as e:
			print(f"compile-time error: {e.msg}")
			return None

		apply_mode_defaults(metadata)

		from src.transform.engine import TransformEngine
		transform_engine = TransformEngine(metadata, evaluator)
		for rule in metadata.transforms:
			transform_engine.add_rule(rule)
		for disable_name in metadata.transform_disables:
			transform_engine.disable_rule(disable_name)

		try:
			parser = Parser(code_tokens)
			program = parser.parse(metadata=metadata)
		except Exception as e:
			print(f"parse error: {e}")
			return None

		typechecker = TypeChecker(program, self.reporter)
		typechecker.check()

		if self.reporter.has_errors():
			self.reporter.print_errors()
			return None

		if metadata.is_safety():
			codegen = SafetyCodeGen(program, filename)
		else:
			codegen = SpeedCodeGen(program, filename)

		codegen.transform_engine = transform_engine

		c_code = codegen.generate()

		os.makedirs(output_dir, exist_ok=True)
		base_name = os.path.splitext(os.path.basename(filename))[0]
		output_path = os.path.join(output_dir, base_name + ".c")

		with open(output_path, "w", encoding="utf-8") as f:
			f.write(c_code)

		return output_path

	def compile_files(self, filepaths: List[str], output_dir: str = "build") -> List[str]:
		results = []
		for fp in filepaths:
			result = self.compile_file(fp, output_dir)
			if result:
				results.append(result)
		return results
