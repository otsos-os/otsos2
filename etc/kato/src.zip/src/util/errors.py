class CompileError(Exception):

	def __init__(self, msg, line=0, col=0, filename="<input>"):
		self.msg = msg
		self.line = line
		self.col = col
		self.filename = filename
		super().__init__(f"error: {filename}:{line}:{col}: {msg}")


class ErrorReporter:

	def __init__(self):
		self.errors = []
		self.warnings = []

	def error(self, msg, line=0, col=0, filename="<input>"):
		self.errors.append(f"error: {filename}:{line}:{col}: {msg}")

	def warning(self, msg, line=0, col=0, filename="<input>"):
		self.warnings.append(f"warning: {filename}:{line}:{col}: {msg}")

	def has_errors(self):
		return len(self.errors) > 0

	def print_errors(self):
		for e in self.errors:
			print(e)
		for w in self.warnings:
			print(w)
