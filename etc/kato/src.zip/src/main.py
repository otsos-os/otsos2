#!/usr/bin/env python3
import sys
import os
import argparse

from src.compiler import Compiler


def main():
	parser = argparse.ArgumentParser(
		description="Kato Compiler - DOD + Functional language that compiles to C"
	)
	parser.add_argument("input", nargs="+", help="input .kato file(s)")
	parser.add_argument("-o", "--output", default="build", help="output directory (default: build)")
	parser.add_argument("--version", action="version", version="Kato Compiler 0.1.0")

	args = parser.parse_args()

	compiler = Compiler()
	results = compiler.compile_files(args.input, args.output)

	if results:
		print(f"compiled {len(results)} file(s):")
		for r in results:
			print(f"  {r}")
	else:
		print("compilation failed")
		sys.exit(1)


if __name__ == "__main__":
	main()
