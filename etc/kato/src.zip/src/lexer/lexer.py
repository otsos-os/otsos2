from dataclasses import dataclass
from typing import List

from src.lexer.tokens import Token, TokenType, KEYWORDS


class LexError(Exception):

	def __init__(self, msg, line, col, filename):
		self.msg = msg
		self.line = line
		self.col = col
		self.filename = filename
		super().__init__(f"lex error: {filename}:{line}:{col}: {msg}")


class Lexer:

	def __init__(self, source, filename="<input>"):
		self.src = source
		self.filename = filename
		self.pos = 0
		self.line = 1
		self.col = 1
		self.tokens: List[Token] = []
		self.in_meta = False

	def _peek(self, offset=0):
		idx = self.pos + offset
		if idx >= len(self.src):
			return '\0'
		return self.src[idx]

	def _advance(self):
		ch = self.src[self.pos]
		self.pos += 1
		if ch == '\n':
			self.line += 1
			self.col = 1
		else:
			self.col += 1
		return ch

	def _make(self, ttype, value):
		return Token(ttype, value, self.line, self.col, self.filename)

	def _error(self, msg):
		raise LexError(msg, self.line, self.col, self.filename)

	def _skip_whitespace_and_comments(self):
		while self.pos < len(self.src):
			ch = self._peek()
			if ch in ' \t\r\n':
				self._advance()
			elif ch == '/' and self._peek(1) == '/':
				while self.pos < len(self.src) and self._peek() != '\n':
					self._advance()
			else:
				break

	def _read_ident(self):
		start = self.pos
		start_line = self.line
		start_col = self.col
		while self.pos < len(self.src) and (self._peek().isalnum() or self._peek() == '_'):
			self._advance()
		value = self.src[start:self.pos]
		ttype = KEYWORDS.get(value, TokenType.IDENT)
		return Token(ttype, value, start_line, start_col, self.filename)

	def _read_number(self):
		start = self.pos
		start_line = self.line
		start_col = self.col
		is_hex = False
		is_bin = False

		if self._peek() == '0' and self._peek(1) in ('x', 'X'):
			is_hex = True
			self._advance()
			self._advance()
			while self.pos < len(self.src) and (self._peek() in '0123456789abcdefABCDEF'):
				self._advance()
			value = self.src[start:self.pos]
			return Token(TokenType.INT_LIT, value, start_line, start_col, self.filename)

		if self._peek() == '0' and self._peek(1) in ('b', 'B'):
			is_bin = True
			self._advance()
			self._advance()
			while self.pos < len(self.src) and self._peek() in '01':
				self._advance()
			value = self.src[start:self.pos]
			return Token(TokenType.INT_LIT, value, start_line, start_col, self.filename)

		while self.pos < len(self.src) and (self._peek().isdigit() or self._peek() == '_'):
			self._advance()

		is_float = False
		if self._peek() == '.' and self._peek(1).isdigit():
			is_float = True
			self._advance()
			while self.pos < len(self.src) and (self._peek().isdigit() or self._peek() == '_'):
				self._advance()

		if self._peek() in ('e', 'E'):
			is_float = True
			self._advance()
			if self._peek() in ('+', '-'):
				self._advance()
			while self.pos < len(self.src) and self._peek().isdigit():
				self._advance()

		value = self.src[start:self.pos].replace('_', '')
		ttype = TokenType.FLOAT_LIT if is_float else TokenType.INT_LIT
		return Token(ttype, value, start_line, start_col, self.filename)

	def _read_char(self):
		start_line = self.line
		start_col = self.col
		self._advance()

		if self._peek() == '\\':
			self._advance()
			esc = self._advance()
			valid = {'n', 't', 'r', '0', '\\', '\'', '"', 'a', 'b', 'f', 'v'}
			if esc not in valid:
				self._error(f"invalid escape sequence: \\{esc}")
			value = f"'\\{esc}'"
		else:
			ch = self._advance()
			value = f"'{ch}'"

		if self._peek() != "'":
			self._error("unterminated char literal")
		self._advance()
		return Token(TokenType.CHAR_LIT, value, start_line, start_col, self.filename)

	def _read_string(self):
		start_line = self.line
		start_col = self.col
		self._advance()
		chars = []

		while self.pos < len(self.src) and self._peek() != '"':
			if self._peek() == '\\':
				self._advance()
				esc = self._advance()
				valid = {'n', 't', 'r', '0', '\\', '\'', '"', 'a', 'b', 'f', 'v'}
				if esc not in valid:
					self._error(f"invalid escape sequence: \\{esc}")
				chars.append(f"\\{esc}")
			else:
				if self._peek() == '\n':
					self._error("unterminated string literal (newline)")
				chars.append(self._advance())

		if self.pos >= len(self.src):
			self._error("unterminated string literal (EOF)")
		self._advance()
		return Token(TokenType.STRING_LIT, '"' + ''.join(chars) + '"', start_line, start_col, self.filename)

	def _read_meta_directive(self):
		start_line = self.line
		start_col = self.col
		start = self.pos
		while self.pos < len(self.src) and (self._peek().isalnum() or self._peek() in '_.'):
			self._advance()
		value = self.src[start:self.pos]
		return Token(TokenType.META_DIRECTIVE, value, start_line, start_col, self.filename)

	def tokenize(self):
		while self.pos < len(self.src):
			if self.in_meta:
				self._lex_meta_token()
			else:
				self._lex_token()

		self.tokens.append(Token(TokenType.EOF, "", self.line, self.col, self.filename))
		return self.tokens

	def _lex_meta_token(self):
		ch = self._peek()

		if ch in ' \t\r':
			self._advance()
			return
		if ch == '\n':
			self._advance()
			return
		if ch == '/' and self._peek(1) == '/':
			while self.pos < len(self.src) and self._peek() != '\n':
				self._advance()
			return

		if ch == '!':
			start_line = self.line
			start_col = self.col
			self._advance()
			rest = ""
			while self.pos < len(self.src) and self._peek() != '\n':
				rest += self._advance()
			rest_stripped = rest.strip()
			if rest_stripped == "END!":
				self.tokens.append(Token(TokenType.META_END, "!END!", start_line, start_col, self.filename))
				self.in_meta = False
				return
			self._error(f"unexpected !{rest} in META block")

		if ch == '$':
			start_line = self.line
			start_col = self.col
			self._advance()
			tok = self._read_meta_directive()
			if tok.value == "else":
				tok = Token(TokenType.ELSE, "else", tok.line, tok.col, tok.filename)
			elif tok.value == "end":
				tok = Token(TokenType.IDENT, "end", tok.line, tok.col, tok.filename)
			self.tokens.append(Token(TokenType.META_DOLLAR, "$", start_line, start_col, self.filename))
			self.tokens.append(tok)
			return

		if ch == '%':
			start_line = self.line
			start_col = self.col
			self._advance()
			self.tokens.append(Token(TokenType.META_PERCENT, "%", start_line, start_col, self.filename))
			return

		if ch.isalpha() or ch == '_':
			start_line = self.line
			start_col = self.col
			start = self.pos
			while self.pos < len(self.src) and (self._peek().isalnum() or self._peek() in '_.'):
				self._advance()
			value = self.src[start:self.pos]
			if value == "as":
				tok = Token(TokenType.META_AS, value, start_line, start_col, self.filename)
			elif value == "if":
				tok = Token(TokenType.IF, value, start_line, start_col, self.filename)
			elif value == "else":
				tok = Token(TokenType.ELSE, value, start_line, start_col, self.filename)
			elif value == "then":
				tok = Token(TokenType.IDENT, value, start_line, start_col, self.filename)
			elif value == "end":
				tok = Token(TokenType.IDENT, value, start_line, start_col, self.filename)
			else:
				tok = Token(TokenType.IDENT, value, start_line, start_col, self.filename)
			self.tokens.append(tok)
			return

		if ch.isdigit():
			tok = self._read_number()
			self.tokens.append(tok)
			return

		if ch == '"':
			tok = self._read_string()
			self.tokens.append(tok)
			return

		if ch == "'":
			tok = self._read_char()
			self.tokens.append(tok)
			return

		start_line = self.line
		start_col = self.col
		two = self.src[self.pos:self.pos + 2]

		if two == '<<':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.SHL, "<<", start_line, start_col, self.filename))
			return
		if two == '>>':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.SHR, ">>", start_line, start_col, self.filename))
			return
		if two == '==':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.EQ, "==", start_line, start_col, self.filename))
			return
		if two == '!=':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.NEQ, "!=", start_line, start_col, self.filename))
			return
		if two == '<=':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.LEQ, "<=", start_line, start_col, self.filename))
			return
		if two == '>=':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.GEQ, ">=", start_line, start_col, self.filename))
			return
		if two == '&&':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.AND, "&&", start_line, start_col, self.filename))
			return
		if two == '||':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.OR, "||", start_line, start_col, self.filename))
			return

		single_meta = {
			',': TokenType.COMMA, '=': TokenType.ASSIGN,
			'-': TokenType.MINUS, '+': TokenType.PLUS,
			'*': TokenType.STAR, '/': TokenType.SLASH,
			'%': TokenType.PERCENT,
			'(': TokenType.LPAREN, ')': TokenType.RPAREN,
			'{': TokenType.LBRACE, '}': TokenType.RBRACE,
			'[': TokenType.LBRACKET, ']': TokenType.RBRACKET,
			';': TokenType.SEMICOLON, ':': TokenType.COLON,
			'.': TokenType.DOT,
			'<': TokenType.LT, '>': TokenType.GT,
			'!': TokenType.NOT, '&': TokenType.AMP,
			'|': TokenType.PIPE, '^': TokenType.CARET,
			'~': TokenType.TILDE,
		}

		if ch in single_meta:
			self._advance()
			self.tokens.append(Token(single_meta[ch], ch, start_line, start_col, self.filename))
			return

		self._error(f"unexpected character '{ch}' in META block")

	def _lex_token(self):
		self._skip_whitespace_and_comments()

		if self.pos >= len(self.src):
			return

		ch = self._peek()

		if ch == '!' and self.src[self.pos:self.pos + 6] == "!META!":
			start_line = self.line
			start_col = self.col
			for _ in range(6):
				self._advance()
			self.tokens.append(Token(TokenType.META_START, "!META!", start_line, start_col, self.filename))
			self.in_meta = True
			return

		if ch.isalpha() or ch == '_':
			tok = self._read_ident()
			if tok.value == "c" and self._peek() == '.':
				start_line = self.line
				start_col = self.col
				self._advance()
				self.tokens.append(Token(TokenType.C_PREFIX, "c.", start_line, start_col, self.filename))
				return
			self.tokens.append(tok)
			return

		if ch.isdigit():
			self.tokens.append(self._read_number())
			return

		if ch == '"':
			self.tokens.append(self._read_string())
			return

		if ch == "'":
			self.tokens.append(self._read_char())
			return

		start_line = self.line
		start_col = self.col

		three = self.src[self.pos:self.pos + 3]
		two = self.src[self.pos:self.pos + 2]
		one = ch

		if three == '...':
			self._advance(); self._advance(); self._advance()
			self.tokens.append(Token(TokenType.ELLIPSIS, "...", start_line, start_col, self.filename))
			return
		if three == '..=':
			self._advance(); self._advance(); self._advance()
			self.tokens.append(Token(TokenType.DOTDOT_EQ, "..=", start_line, start_col, self.filename))
			return

		if two == '//':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.DOUBLE_SLASH, "//", start_line, start_col, self.filename))
			return
		if two == '..':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.DOTDOT, "..", start_line, start_col, self.filename))
			return
		if two == '==':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.EQ, "==", start_line, start_col, self.filename))
			return
		if two == '!=':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.NEQ, "!=", start_line, start_col, self.filename))
			return
		if two == '<=':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.LEQ, "<=", start_line, start_col, self.filename))
			return
		if two == '>=':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.GEQ, ">=", start_line, start_col, self.filename))
			return
		if two == '&&':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.AND, "&&", start_line, start_col, self.filename))
			return
		if two == '||':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.OR, "||", start_line, start_col, self.filename))
			return
		if two == '->':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.ARROW, "->", start_line, start_col, self.filename))
			return
		if two == '=>':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.FAT_ARROW, "=>", start_line, start_col, self.filename))
			return
		if two == '+=':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.PLUS_ASSIGN, "+=", start_line, start_col, self.filename))
			return
		if two == '-=':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.MINUS_ASSIGN, "-=", start_line, start_col, self.filename))
			return
		if two == '*=':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.STAR_ASSIGN, "*=", start_line, start_col, self.filename))
			return
		if two == '/=':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.SLASH_ASSIGN, "/=", start_line, start_col, self.filename))
			return
		if two == '%=':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.PERCENT_ASSIGN, "%=", start_line, start_col, self.filename))
			return
		if two == '++':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.INC, "++", start_line, start_col, self.filename))
			return
		if two == '--':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.DEC, "--", start_line, start_col, self.filename))
			return
		if two == '<<':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.SHL, "<<", start_line, start_col, self.filename))
			return
		if two == '>>':
			self._advance(); self._advance()
			self.tokens.append(Token(TokenType.SHR, ">>", start_line, start_col, self.filename))
			return

		single = {
			'+': TokenType.PLUS, '-': TokenType.MINUS, '*': TokenType.STAR,
			'/': TokenType.SLASH, '%': TokenType.PERCENT, '=': TokenType.ASSIGN,
			'<': TokenType.LT, '>': TokenType.GT, '!': TokenType.NOT,
			'&': TokenType.AMP, '|': TokenType.PIPE, '^': TokenType.CARET,
			'~': TokenType.TILDE, '.': TokenType.DOT,
			'(': TokenType.LPAREN, ')': TokenType.RPAREN,
			'{': TokenType.LBRACE, '}': TokenType.RBRACE,
			'[': TokenType.LBRACKET, ']': TokenType.RBRACKET,
			';': TokenType.SEMICOLON, ':': TokenType.COLON,
			',': TokenType.COMMA,
		}

		if one in single:
			self._advance()
			self.tokens.append(Token(single[one], one, start_line, start_col, self.filename))
			return

		self._error(f"unexpected character '{one}'")
