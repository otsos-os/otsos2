from enum import Enum, auto
from dataclasses import dataclass


class TokenType(Enum):
	IDENT = auto()
	INT_LIT = auto()
	FLOAT_LIT = auto()
	CHAR_LIT = auto()
	STRING_LIT = auto()
	BOOL_LIT = auto()

	LET = auto()
	MUT = auto()
	FUNC = auto()
	STRUCT = auto()
	ENUM = auto()
	CONST = auto()
	IF = auto()
	ELSE = auto()
	MATCH = auto()
	WHERE = auto()
	MAP = auto()
	FILTER = auto()
	FOLD = auto()
	IN = auto()
	RETURN = auto()
	BREAK = auto()
	CONTINUE = auto()
	IMPORT = auto()
	EXPORT = auto()
	TRUE = auto()
	FALSE = auto()
	VOID = auto()
	WHILE = auto()

	PLUS = auto()
	MINUS = auto()
	STAR = auto()
	SLASH = auto()
	DOUBLE_SLASH = auto()
	PERCENT = auto()
	EQ = auto()
	NEQ = auto()
	LT = auto()
	GT = auto()
	LEQ = auto()
	GEQ = auto()
	AND = auto()
	OR = auto()
	NOT = auto()
	AMP = auto()
	PIPE = auto()
	CARET = auto()
	TILDE = auto()
	SHL = auto()
	SHR = auto()

	ASSIGN = auto()
	PLUS_ASSIGN = auto()
	MINUS_ASSIGN = auto()
	STAR_ASSIGN = auto()
	SLASH_ASSIGN = auto()
	PERCENT_ASSIGN = auto()

	INC = auto()
	DEC = auto()

	ARROW = auto()
	FAT_ARROW = auto()

	DOTDOT = auto()
	DOTDOT_EQ = auto()
	DOT = auto()
	ELLIPSIS = auto()

	LPAREN = auto()
	RPAREN = auto()
	LBRACE = auto()
	RBRACE = auto()
	LBRACKET = auto()
	RBRACKET = auto()

	SEMICOLON = auto()
	COLON = auto()
	COMMA = auto()

	C_PREFIX = auto()
	C_LBRACE = auto()
	RBRACE_C = auto()

	META_START = auto()
	META_END = auto()
	META_DIRECTIVE = auto()
	META_DOLLAR = auto()
	META_PERCENT = auto()
	META_AS = auto()

	EOF = auto()


KEYWORDS = {
	"let": TokenType.LET,
	"mut": TokenType.MUT,
	"func": TokenType.FUNC,
	"struct": TokenType.STRUCT,
	"enum": TokenType.ENUM,
	"const": TokenType.CONST,
	"if": TokenType.IF,
	"else": TokenType.ELSE,
	"match": TokenType.MATCH,
	"where": TokenType.WHERE,
	"map": TokenType.MAP,
	"filter": TokenType.FILTER,
	"fold": TokenType.FOLD,
	"in": TokenType.IN,
	"return": TokenType.RETURN,
	"break": TokenType.BREAK,
	"continue": TokenType.CONTINUE,
	"import": TokenType.IMPORT,
	"export": TokenType.EXPORT,
	"true": TokenType.TRUE,
	"false": TokenType.FALSE,
	"void": TokenType.VOID,
	"while": TokenType.WHILE,
	"as": TokenType.META_AS,
}


@dataclass
class Token:
	type: TokenType
	value: str
	line: int
	col: int
	filename: str

	def __repr__(self):
		return f"Token({self.type.name}, {self.value!r}, {self.filename}:{self.line}:{self.col})"
