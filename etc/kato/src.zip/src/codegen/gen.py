from typing import List, Optional

from src.parser.ast import (
	Program, FuncDecl, Param, StructDecl, StructField,
	EnumDecl, ConstDecl, TypeRef, Literal, Identifier,
	BinaryOp, UnaryOp, Assignment, IndexAccess, FieldAccess,
	Call, LetBinding, IfExpr, MatchExpr, MatchArm,
	MapExpr, FilterExpr, FoldExpr, WhileLoop, ReturnStmt,
	BreakStmt, ContinueStmt, Block,
)
from src.metadata.nodes import Metadata

PRIMITIVES = {"int", "int64", "uint", "uint64", "float", "double", "char", "bool", "void"}


class CodeGen:

	def __init__(self, program: Program, filename: str = "<input>"):
		self.program = program
		self.meta: Metadata = program.metadata
		self.filename = filename
		self.lines: List[str] = []
		self.indent_level = 0
		self.temp_counter = 0
		self.struct_table = {}
		self.enum_table = {}
		self.const_table = {}
		self.func_table = {}
		self.pointer_vars: set = set()
		self.transform_engine = None

		for s in program.structs:
			self.struct_table[s.name] = s
		for e in program.enums:
			self.enum_table[e.name] = e
		for c in program.consts:
			self.const_table[c.name] = c
		for f in program.functions:
			self.func_table[f.name] = f

	def _emit(self, line=""):
		if line:
			self.lines.append("\t" * self.indent_level + line)
		else:
			self.lines.append("")

	def _blank(self):
		if self.lines and self.lines[-1] != "":
			self.lines.append("")

	def _temp(self, prefix="tmp"):
		self.temp_counter += 1
		return f"__{prefix}_{self.temp_counter}"

	def _indent(self):
		self.indent_level += 1

	def _dedent(self):
		self.indent_level -= 1

	def _c_type(self, type_ref: TypeRef) -> str:
		return self._c_type_name(type_ref.name, type_ref.is_pointer)

	def _c_type_name(self, name: str, is_pointer: bool = False) -> str:
		t = name
		if self.meta:
			td = self.meta.get_type_def(name)
			if td:
				safety = self.meta.is_safety()
				t = td.c_type(safety=safety)
			elif safety := self.meta.is_safety():
				t = self._safety_type(name)
		if is_pointer:
			t += " *"
		return t

	def _safety_type(self, name: str) -> str:
		mapping = {
			"int": "int32_t",
			"int64": "int64_t",
			"uint": "uint32_t",
			"uint64": "uint64_t",
			"float": "float",
			"double": "double",
			"char": "char",
			"bool": "bool",
			"void": "void",
		}
		return mapping.get(name, name)

	def _c_name(self, name: str) -> str:
		if self.meta:
			return self.meta.get_c_name(name)
		return name

	def _gen_array_size(self, size) -> str:
		if isinstance(size, str):
			return size
		if isinstance(size, int):
			return str(size)
		return self._gen_expr(size)

	def _emit_manifest(self):
		if not self.meta:
			return
		self._emit("/* !DEFINES!")
		self._emit(f"")
		self._emit(f"$mode {self.meta.mode}")
		for name, td in self.meta.type_defs.items():
			self._emit(f"$define %type {name} as {td.kind}")
		for name, fc in self.meta.func_contracts.items():
			args_str = ", ".join(f"{a}: {t}" for a, t in fc.args.items()) if fc.args else "void"
			if fc.is_procedure():
				self._emit(f"$define %func {name} as {fc.kind} args: {{ {args_str} }}")
			else:
				self._emit(f"$define %func {name} as {fc.kind} args: {{ {args_str} }} returns: {fc.returns}")
		self._emit("")
		self._emit("*/")
		self._emit("")
		self._emit("/* !SPACE!")
		self._emit("")
		for sd in self.meta.space_decls:
			self._emit(f"$space %{sd.visibility} {', '.join(sd.symbols)}")
		self._emit("")
		self._emit("*/")
		self._blank()

	def _emit_includes(self):
		if self.meta and self.meta.is_safety():
			self._emit("#include <stdint.h>")
			self._emit("#include <stdbool.h>")
			self._emit("#include <stddef.h>")
		else:
			self._emit("#include <stdbool.h>")
		for inc in (self.meta.c_includes if self.meta else []):
			self._emit(f"#include <{inc.header}>")
		if self.meta:
			for ec in self.meta.emit_cs:
				self._emit(ec.code)
		self._blank()

	def _emit_constants(self):
		for c in self.program.consts:
			self._emit(f"#define {c.name} {self._gen_expr(c.value)}")
		if self.program.consts:
			self._blank()

	def _emit_structs(self):
		for s in self.program.structs:
			self._emit(f"typedef struct {{")
			self._indent()
			for field in s.fields:
				if field.type_ref.is_fixed_array and field.array_size is not None:
					size_str = self._gen_array_size(field.array_size)
					self._emit(f"{self._c_type(field.type_ref)} {field.name}[{size_str}];")
				else:
					self._emit(f"{self._c_type(field.type_ref)} {field.name};")
			self._dedent()
			self._emit(f"}} {s.name};")
			self._blank()

	def _emit_enums(self):
		for e in self.program.enums:
			self._emit(f"typedef enum {{")
			self._indent()
			for i, v in enumerate(e.variants):
				if v.value is not None:
					self._emit(f"{v.name} = {v.value},")
				else:
					self._emit(f"{v.name},")
			self._dedent()
			self._emit(f"}} {e.name};")
			self._blank()

	def _emit_func_decls(self):
		for f in self.program.functions:
			if self.meta and self.meta.is_internal(f.name):
				self._emit(f"static {self._func_signature(f)};")
		if self.meta:
			for f in self.program.functions:
				if self.meta.is_exported(f.name):
					self._emit(f"{self._func_signature(f)};")
		self._blank()

	def _param_c_type(self, p: Param) -> str:
		if p.type_ref.is_mut and not p.type_ref.is_pointer:
			return self._c_type_name(p.type_ref.name) + " *"
		if p.is_mut and not p.type_ref.is_pointer:
			return self._c_type_name(p.type_ref.name) + " *"
		if p.type_ref.is_pointer:
			return self._c_type_name(p.type_ref.name) + " *"
		return self._c_type(p.type_ref)

	def _func_signature(self, func: FuncDecl) -> str:
		ret = self._c_type(func.return_type)
		params = []
		for p in func.params:
			params.append(self._param_c_type(p))
		params_str = ", ".join(params) if params else "void"
		return f"{ret} {self._c_name(func.name)}({params_str})"

	def _gen_expr(self, expr) -> str:
		if isinstance(expr, Literal):
			return self._gen_literal(expr)
		elif isinstance(expr, Identifier):
			return expr.name
		elif isinstance(expr, BinaryOp):
			return self._gen_binary(expr)
		elif isinstance(expr, UnaryOp):
			return self._gen_unary(expr)
		elif isinstance(expr, Assignment):
			return f"({self._gen_expr(expr.target)} {expr.op} {self._gen_expr(expr.value)})"
		elif isinstance(expr, IndexAccess):
			return f"{self._gen_expr(expr.target)}[{self._gen_expr(expr.index)}]"
		elif isinstance(expr, FieldAccess):
			if isinstance(expr.target, Identifier) and expr.target.name in self.pointer_vars:
				return f"{self._gen_expr(expr.target)}->{expr.field}"
			return f"{self._gen_expr(expr.target)}.{expr.field}"
		elif isinstance(expr, Call):
			return self._gen_call(expr)
		elif isinstance(expr, IfExpr):
			return self._gen_if_expr(expr)
		return "/* unhandled expr */"

	def _gen_literal(self, lit: Literal) -> str:
		if lit.lit_type == "bool":
			return lit.value
		if lit.lit_type == "zero_init":
			return "{0}"
		if lit.lit_type == "struct_init":
			return "{0}"
		if lit.lit_type == "c_var":
			return lit.value
		return lit.value

	def _gen_binary(self, binop: BinaryOp) -> str:
		if binop.op == "//":
			return f"({self._gen_expr(binop.left)} / {self._gen_expr(binop.right)})"
		left = self._gen_expr(binop.left)
		right = self._gen_expr(binop.right)
		return f"({left} {binop.op} {right})"

	def _gen_unary(self, unop: UnaryOp) -> str:
		operand = self._gen_expr(unop.operand)
		if unop.prefix:
			if unop.op == "&":
				return f"&{operand}"
			if unop.op == "*":
				return f"*{operand}"
			return f"({unop.op}{operand})"
		else:
			return f"({operand}{unop.op})"

	def _gen_call(self, call: Call) -> str:
		args = ", ".join(self._gen_expr(a) for a in call.args)
		if call.is_c_call:
			return f"{call.name}({args})"
		return f"{self._c_name(call.name)}({args})"

	def _gen_if_expr(self, if_expr: IfExpr) -> str:
		return f"({self._gen_expr(if_expr.cond)} ? {self._gen_expr(if_expr.then_body[0]) if if_expr.then_body else '0'} : {self._gen_expr(if_expr.else_body[0]) if if_expr.else_body else '0'})"

	def generate(self) -> str:
		self._emit(f"/* Generated by Kato Compiler */")
		self._emit(f"/* Mode: {self.meta.mode if self.meta else 'speed'} */")
		self._emit(f"/* Source: {self.filename} */")
		self._blank()
		self._emit_manifest()
		self._emit_includes()
		self._emit_constants()
		self._emit_structs()
		self._emit_enums()
		self._emit_func_decls()

		for f in self.program.functions:
			self._emit_func(f)
			self._blank()

		return "\n".join(self.lines) + "\n"

	def _emit_func(self, func: FuncDecl):
		pass
