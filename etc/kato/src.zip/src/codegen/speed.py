from typing import List, Set

from src.parser.ast import (
	FuncDecl, Param, TypeRef, Literal, Identifier,
	BinaryOp, UnaryOp, Assignment, IndexAccess, FieldAccess,
	Call, LetBinding, IfExpr, MatchExpr, MatchArm,
	MapExpr, FilterExpr, FoldExpr, WhileLoop, ReturnStmt,
	BreakStmt, ContinueStmt,
)
from src.codegen.gen import CodeGen

PRIMITIVES = {"int", "int64", "uint", "uint64", "float", "double", "char", "bool", "void"}


class SpeedCodeGen(CodeGen):

	def _param_c_type(self, p: Param) -> str:
		if p.type_ref.is_mut and not p.type_ref.is_pointer:
			base = self._c_type_name(p.type_ref.name)
			if self.meta and not self.meta.is_safety():
				return base + " *restrict"
			return base + " *"
		if p.is_mut and not p.type_ref.is_pointer:
			base = self._c_type_name(p.type_ref.name)
			if self.meta and not self.meta.is_safety():
				return base + " *restrict"
			return base + " *"
		if p.type_ref.is_pointer:
			base = self._c_type_name(p.type_ref.name)
			if self.meta and not self.meta.is_safety():
				return base + " *restrict"
			return base + " *"
		return self._c_type(p.type_ref)

	def _emit_func(self, func: FuncDecl):
		ret_type = self._c_type(func.return_type)
		params = []
		for p in func.params:
			c_type = self._param_c_type(p)
			params.append(f"{c_type} {p.name}")
		params_str = ", ".join(params) if params else "void"

		inline_mode = self.meta.get_inline_mode(func.name) if self.meta else "auto"

		prefix = ""
		if self.meta and self.meta.is_internal(func.name):
			prefix = "static "
		if inline_mode == "always" and self.meta and self.meta.is_internal(func.name):
			prefix = "static inline "

		self._emit(f"{prefix}{ret_type}")
		self._emit(f"{self._c_name(func.name)}({params_str})")
		self._emit("{")

		self._indent()

		self.pointer_vars = set()
		for p in func.params:
			if (p.type_ref.is_mut or p.is_mut) and not p.type_ref.is_pointer:
				self.pointer_vars.add(p.name)
			elif p.type_ref.is_pointer:
				self.pointer_vars.add(p.name)

		decl_vars = self._collect_loop_vars(func.body)
		for var, vtype in decl_vars.items():
			self._emit(f"{vtype} {var};")

		self._emit_func_body(func)

		self._dedent()
		self._emit("}")

	def _collect_loop_vars(self, stmts) -> dict:
		vars = {}
		for stmt in stmts:
			vars.update(self._collect_loop_vars_stmt(stmt))
		return vars

	def _collect_loop_vars_stmt(self, stmt) -> dict:
		vars = {}
		if isinstance(stmt, MapExpr):
			vars[stmt.index_var] = "int"
			for s in stmt.body:
				vars.update(self._collect_loop_vars_stmt(s))
		elif isinstance(stmt, FoldExpr):
			vars[stmt.index_var] = "int"
			vars["acc"] = "float"
			for s in stmt.body:
				vars.update(self._collect_loop_vars_stmt(s))
		elif isinstance(stmt, FilterExpr):
			vars[stmt.index_var] = "int"
		elif isinstance(stmt, WhileLoop):
			for s in stmt.body:
				vars.update(self._collect_loop_vars_stmt(s))
		elif isinstance(stmt, IfExpr):
			for s in stmt.then_body:
				vars.update(self._collect_loop_vars_stmt(s))
			if stmt.else_body:
				for s in stmt.else_body:
					vars.update(self._collect_loop_vars_stmt(s))
		elif isinstance(stmt, MatchExpr):
			for arm in stmt.arms:
				for s in arm.body:
					vars.update(self._collect_loop_vars_stmt(s))
		return vars

	def _emit_func_body(self, func: FuncDecl):
		ret_type = func.return_type.name
		has_explicit_return = any(isinstance(s, ReturnStmt) for s in func.body)

		if not has_explicit_return and ret_type != "void":
			last_expr = None
			last_fold = None
			body = list(func.body)
			while body:
				last = body[-1]
				if isinstance(last, (Identifier, BinaryOp, UnaryOp, Call, Literal, IndexAccess, FieldAccess)):
					last_expr = last
					body = body[:-1]
					break
				elif isinstance(last, FoldExpr):
					last_fold = last
					body = body[:-1]
					break
				elif isinstance(last, IfExpr):
					break
				else:
					break

			for stmt in body:
				self._emit_stmt(stmt)

			if last_fold:
				self._emit_fold(last_fold)
				self._emit(f"return acc;")
			elif last_expr:
				self._emit(f"return {self._gen_expr(last_expr)};")
		else:
			for stmt in func.body:
				self._emit_stmt(stmt)

	def _emit_stmt(self, stmt):
		if isinstance(stmt, LetBinding):
			self._emit_let(stmt)
		elif isinstance(stmt, IfExpr):
			self._emit_if(stmt)
		elif isinstance(stmt, MatchExpr):
			self._emit_match(stmt)
		elif isinstance(stmt, MapExpr):
			self._emit_map(stmt)
		elif isinstance(stmt, FilterExpr):
			self._emit_filter(stmt)
		elif isinstance(stmt, FoldExpr):
			self._emit_fold(stmt)
		elif isinstance(stmt, WhileLoop):
			self._emit_while(stmt)
		elif isinstance(stmt, ReturnStmt):
			self._emit_return(stmt)
		elif isinstance(stmt, BreakStmt):
			self._emit("break;")
		elif isinstance(stmt, ContinueStmt):
			self._emit("continue;")
		elif isinstance(stmt, Assignment):
			self._emit_assignment(stmt)
		elif isinstance(stmt, UnaryOp):
			self._emit(f"{self._gen_expr(stmt)};")
		elif isinstance(stmt, Call):
			self._emit(f"{self._gen_expr(stmt)};")
		elif isinstance(stmt, Identifier):
			pass
		elif isinstance(stmt, Literal):
			pass
		elif isinstance(stmt, BinaryOp):
			self._emit(f"{self._gen_expr(stmt)};")
		elif isinstance(stmt, IndexAccess):
			self._emit(f"{self._gen_expr(stmt)};")
		elif isinstance(stmt, FieldAccess):
			self._emit(f"{self._gen_expr(stmt)};")

	def _emit_let(self, let: LetBinding):
		type_name = "int"
		array_suffix = ""
		if let.type_ref:
			type_name = self._c_type_name(let.type_ref.name)
			if let.type_ref.is_fixed_array and let.type_ref.array_size:
				array_suffix = f"[{let.type_ref.array_size}]"
			elif let.type_ref.is_array:
				array_suffix = "[]"
		elif let.inferred_type:
			type_name = let.inferred_type

		if let.value:
			if array_suffix:
				self._emit(f"{type_name} {let.name}{array_suffix} = {self._gen_expr(let.value)};")
			else:
				self._emit(f"{type_name} {let.name} = {self._gen_expr(let.value)};")
		else:
			if array_suffix:
				self._emit(f"{type_name} {let.name}{array_suffix};")
			else:
				self._emit(f"{type_name} {let.name};")

	def _emit_if(self, if_expr: IfExpr):
		self._emit(f"if ({self._gen_expr(if_expr.cond)}) {{")
		self._indent()
		for stmt in if_expr.then_body:
			self._emit_stmt(stmt)
		self._dedent()
		if if_expr.else_body:
			self._emit(f"}} else {{")
			self._indent()
			for stmt in if_expr.else_body:
				self._emit_stmt(stmt)
			self._dedent()
		self._emit("}")

	def _emit_match(self, match: MatchExpr):
		subject = self._gen_expr(match.subject)
		first = True
		for arm in match.arms:
			if arm.is_wildcard:
				if first:
					self._emit(f"{{")
				else:
					self._emit(f"}} else {{")
			else:
				if first:
					self._emit(f"if ({subject} == {self._gen_expr(arm.pattern)}) {{")
				else:
					self._emit(f"}} else if ({subject} == {self._gen_expr(arm.pattern)}) {{")
			self._indent()
			for stmt in arm.body:
				self._emit_stmt(stmt)
			self._dedent()
			first = False
		self._emit("}")

	def _emit_map(self, map_expr: MapExpr):
		idx = map_expr.index_var
		start = self._gen_expr(map_expr.range.start)
		end = self._gen_expr(map_expr.range.end)

		if map_expr.range.inclusive:
			cond = f"{idx} <= {end}"
		else:
			cond = f"{idx} < {end}"

		if map_expr.condition:
			self._emit(f"for ({idx} = {start}; {cond}; ++{idx}) {{")
			self._indent()
			self._emit(f"if ({self._gen_expr(map_expr.condition)}) {{")
			self._indent()
			for stmt in map_expr.body:
				self._emit_stmt(stmt)
			self._dedent()
			self._emit("}")
			self._dedent()
		else:
			self._emit(f"for ({idx} = {start}; {cond}; ++{idx}) {{")
			self._indent()
			for stmt in map_expr.body:
				self._emit_stmt(stmt)
			self._dedent()

		self._emit("}")

	def _emit_filter(self, filter_expr: FilterExpr):
		idx = filter_expr.index_var
		start = self._gen_expr(filter_expr.range.start)
		end = self._gen_expr(filter_expr.range.end)
		count_var = self._temp("filter_count")

		self._emit(f"int {count_var} = 0;")
		self._emit(f"for ({idx} = {start}; {idx} < {end}; ++{idx}) {{")
		self._indent()
		if filter_expr.condition:
			self._emit(f"if ({self._gen_expr(filter_expr.condition)}) {{")
			self._indent()
			self._emit(f"++{count_var};")
			self._dedent()
			self._emit("}")
		else:
			self._emit(f"++{count_var};")
		self._dedent()
		self._emit("}")

	def _emit_fold(self, fold_expr: FoldExpr):
		idx = fold_expr.index_var
		start = self._gen_expr(fold_expr.range.start)
		end = self._gen_expr(fold_expr.range.end)

		self._emit(f"acc = {self._gen_expr(fold_expr.initial)};")
		self._emit(f"for ({idx} = {start}; {idx} < {end}; ++{idx}) {{")
		self._indent()
		if fold_expr.condition:
			self._emit(f"if ({self._gen_expr(fold_expr.condition)}) {{")
			self._indent()
			for stmt in fold_expr.body:
				self._emit_fold_stmt(stmt)
			self._dedent()
			self._emit("}")
		else:
			for stmt in fold_expr.body:
				self._emit_fold_stmt(stmt)
		self._dedent()
		self._emit("}")

	def _emit_fold_stmt(self, stmt):
		if isinstance(stmt, BinaryOp):
			self._emit(f"acc = {self._gen_expr(stmt)};")
		elif isinstance(stmt, Identifier):
			self._emit(f"acc = {stmt.name};")
		elif isinstance(stmt, Call):
			self._emit(f"acc = {self._gen_expr(stmt)};")
		elif isinstance(stmt, LetBinding):
			self._emit_let(stmt)
		elif isinstance(stmt, IfExpr):
			self._emit_if(stmt)
		else:
			self._emit(f"{self._gen_expr(stmt)};")

	def _emit_while(self, while_loop: WhileLoop):
		self._emit(f"while ({self._gen_expr(while_loop.cond)}) {{")
		self._indent()
		for stmt in while_loop.body:
			self._emit_stmt(stmt)
		self._dedent()
		self._emit("}")

	def _emit_return(self, ret: ReturnStmt):
		if ret.value:
			self._emit(f"return {self._gen_expr(ret.value)};")
		else:
			self._emit("return;")

	def _emit_assignment(self, assign: Assignment):
		target = self._gen_assignment_target(assign.target)
		value = self._gen_expr(assign.value)
		self._emit(f"{target} {assign.op} {value};")

	def _gen_assignment_target(self, target) -> str:
		if isinstance(target, Identifier) and target.name in self.pointer_vars:
			return f"*{target.name}"
		if isinstance(target, FieldAccess):
			if isinstance(target.target, Identifier) and target.target.name in self.pointer_vars:
				return f"{target.target.name}->{target.field}"
			return f"{self._gen_expr(target.target)}.{target.field}"
		if isinstance(target, IndexAccess):
			return self._gen_expr(target)
		return self._gen_expr(target)
