from dataclasses import dataclass, field
from typing import List, Optional, Any


@dataclass
class Node:
	line: int = 0
	col: int = 0
	filename: str = ""


@dataclass
class TypeRef(Node):
	name: str = ""
	is_pointer: bool = False
	is_array: bool = False
	array_size: Optional[Any] = None
	is_fixed_array: bool = False
	is_mut: bool = False

	def c_name(self, safety: bool = False):
		t = self.name
		if safety:
			t = _to_safety_type(t)
		if self.is_pointer:
			t += "*"
		return t


def _to_safety_type(name):
	mapping = {
		"int": "int32_t",
		"int64": "int64_t",
		"uint": "uint32_t",
		"uint64": "uint64_t",
		"float": "float",
		"double": "double",
		"char": "char",
		"bool": "bool",
		"void": "void",
	}
	return mapping.get(name, name)


@dataclass
class FuncTypeRef(Node):
	params: List[TypeRef] = field(default_factory=list)
	return_type: TypeRef = field(default_factory=lambda: TypeRef())


@dataclass
class Literal(Node):
	value: str = ""
	lit_type: str = "int"


@dataclass
class Identifier(Node):
	name: str = ""


@dataclass
class BinaryOp(Node):
	op: str = ""
	left: Any = None
	right: Any = None


@dataclass
class UnaryOp(Node):
	op: str = ""
	operand: Any = None
	prefix: bool = True


@dataclass
class Assignment(Node):
	target: Any = None
	op: str = "="
	value: Any = None


@dataclass
class IndexAccess(Node):
	target: Any = None
	index: Any = None


@dataclass
class FieldAccess(Node):
	target: Any = None
	field: str = ""


@dataclass
class Call(Node):
	name: str = ""
	args: List[Any] = field(default_factory=list)
	is_c_call: bool = False


@dataclass
class RangeExpr(Node):
	start: Any = None
	end: Any = None
	inclusive: bool = False


@dataclass
class LetBinding(Node):
	name: str = ""
	type_ref: Optional[TypeRef] = None
	is_mut: bool = False
	value: Optional[Any] = None
	inferred_type: Optional[str] = None


@dataclass
class DestructureBinding(Node):
	fields: List[str] = field(default_factory=list)
	value: Any = None


@dataclass
class IfExpr(Node):
	cond: Any = None
	then_body: List[Any] = field(default_factory=list)
	else_body: List[Any] = field(default_factory=list)
	is_expr: bool = False


@dataclass
class MatchArm(Node):
	pattern: Any = None
	body: List[Any] = field(default_factory=list)
	is_wildcard: bool = False


@dataclass
class MatchExpr(Node):
	subject: Any = None
	arms: List[MatchArm] = field(default_factory=list)
	is_expr: bool = False


@dataclass
class MapExpr(Node):
	index_var: str = ""
	range: RangeExpr = None
	condition: Optional[Any] = None
	body: List[Any] = field(default_factory=list)


@dataclass
class FilterExpr(Node):
	index_var: str = ""
	range: RangeExpr = None
	condition: Optional[Any] = None


@dataclass
class FoldExpr(Node):
	initial: Any = None
	index_var: str = ""
	range: RangeExpr = None
	condition: Optional[Any] = None
	body: List[Any] = field(default_factory=list)


@dataclass
class WhileLoop(Node):
	cond: Any = None
	body: List[Any] = field(default_factory=list)


@dataclass
class BreakStmt(Node):
	pass


@dataclass
class ContinueStmt(Node):
	pass


@dataclass
class ReturnStmt(Node):
	value: Optional[Any] = None


@dataclass
class Block(Node):
	statements: List[Any] = field(default_factory=list)


@dataclass
class StructField(Node):
	name: str = ""
	type_ref: TypeRef = None
	array_size: Optional[Any] = None


@dataclass
class StructDecl(Node):
	name: str = ""
	fields: List[StructField] = field(default_factory=list)


@dataclass
class EnumVariant(Node):
	name: str = ""
	value: Optional[int] = None


@dataclass
class EnumDecl(Node):
	name: str = ""
	variants: List[EnumVariant] = field(default_factory=list)


@dataclass
class ConstDecl(Node):
	name: str = ""
	type_ref: TypeRef = None
	value: Any = None


@dataclass
class Param(Node):
	name: str = ""
	type_ref: TypeRef = None
	is_mut: bool = False


@dataclass
class FuncDecl(Node):
	name: str = ""
	params: List[Param] = field(default_factory=list)
	return_type: TypeRef = None
	body: List[Any] = field(default_factory=list)
	is_pure: bool = True
	has_early_return: bool = False


@dataclass
class ImportDecl(Node):
	module_name: str = ""


@dataclass
class CCodeBlock(Node):
	code: str = ""


@dataclass
class Program(Node):
	metadata: Any = None
	structs: List[StructDecl] = field(default_factory=list)
	enums: List[EnumDecl] = field(default_factory=list)
	consts: List[ConstDecl] = field(default_factory=list)
	functions: List[FuncDecl] = field(default_factory=list)
	imports: List[ImportDecl] = field(default_factory=list)
