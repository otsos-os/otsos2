from typing import List, Optional

from src.lexer.tokens import Token, TokenType
from src.parser.ast import (
	Program, FuncDecl, Param, StructDecl, StructField,
	EnumDecl, EnumVariant, ConstDecl, ImportDecl,
	TypeRef, FuncTypeRef, Literal, Identifier, BinaryOp, UnaryOp,
	Assignment, IndexAccess, FieldAccess, Call, RangeExpr,
	LetBinding, DestructureBinding, IfExpr, MatchExpr, MatchArm,
	MapExpr, FilterExpr, FoldExpr, WhileLoop, BreakStmt, ContinueStmt,
	ReturnStmt, Block, CCodeBlock,
)


class ParseError(Exception):

	def __init__(self, msg, line, col, filename):
		self.msg = msg
		self.line = line
		self.col = col
		self.filename = filename
		super().__init__(f"parse error: {filename}:{line}:{col}: {msg}")


class Parser:

	def __init__(self, tokens: List[Token]):
		self.tokens = tokens
		self.pos = 0

	def _peek(self, offset=0):
		idx = self.pos + offset
		if idx >= len(self.tokens):
			return self.tokens[-1]
		return self.tokens[idx]

	def _advance(self):
		tok = self.tokens[self.pos]
		if self.pos < len(self.tokens) - 1:
			self.pos += 1
		return tok

	def _check(self, ttype):
		return self._peek().type == ttype

	def _match(self, *ttypes):
		if self._peek().type in ttypes:
			return self._advance()
		return None

	def _expect(self, ttype, msg=None):
		tok = self._peek()
		if tok.type != ttype:
			err = msg or f"expected {ttype.name}, got {tok.type.name} ('{tok.value}')"
			self._error(err)
		return self._advance()

	def _error(self, msg):
		tok = self._peek()
		raise ParseError(msg, tok.line, tok.col, tok.filename)

	def parse(self, metadata=None):
		program = Program()

		meta_end_found = False
		for i, tok in enumerate(self.tokens):
			if tok.type == TokenType.META_END:
				meta_end_found = True
				break

		while self._peek().type not in (TokenType.EOF, TokenType.META_END):
			if not meta_end_found:
				break
			self._parse_top_level(program)

		while self._peek().type != TokenType.EOF:
			self._parse_top_level(program)

		program.metadata = metadata
		return program

	def _parse_top_level(self, program):
		tok = self._peek()

		if tok.type == TokenType.IMPORT:
			self._parse_import(program)
		elif tok.type == TokenType.STRUCT:
			program.structs.append(self._parse_struct())
		elif tok.type == TokenType.ENUM:
			program.enums.append(self._parse_enum())
		elif tok.type == TokenType.CONST:
			program.consts.append(self._parse_const())
		elif tok.type == TokenType.FUNC:
			program.functions.append(self._parse_func())
		elif tok.type == TokenType.IDENT and tok.value == "c" and self._peek(1).type == TokenType.LBRACE:
			program.imports.append(self._parse_c_code_block())
		elif tok.type == TokenType.EOF:
			return
		else:
			self._error(f"unexpected token at top level: {tok.type.name} ('{tok.value}')")

	def _parse_import(self, program):
		self._expect(TokenType.IMPORT)
		name = self._expect(TokenType.IDENT).value
		if self._peek().type == TokenType.SEMICOLON:
			self._advance()
		program.imports.append(ImportDecl(module_name=name))

	def _parse_c_code_block(self):
		self._advance()
		tok = self._advance()
		code = tok.value if tok.type == TokenType.IDENT else ""
		self._expect(TokenType.RBRACE)
		if self._peek().type == TokenType.SEMICOLON:
			self._advance()
		return CCodeBlock(code=code, line=tok.line, col=tok.col)

	def _parse_struct(self):
		tok = self._expect(TokenType.STRUCT)
		name = self._expect(TokenType.IDENT).value
		self._expect(TokenType.LBRACE)

		fields = []
		while self._peek().type != TokenType.RBRACE:
			field_tok = self._expect(TokenType.IDENT)
			field_name = self._expect(TokenType.IDENT).value

			array_size = None
			if self._peek().type == TokenType.LBRACKET:
				self._advance()
				array_size = self._parse_expr()
				self._expect(TokenType.RBRACKET)

			self._expect(TokenType.SEMICOLON)

			type_ref = TypeRef(name=field_tok.value, line=field_tok.line, col=field_tok.col)
			if array_size is not None:
				type_ref.is_array = True
				type_ref.is_fixed_array = True
				type_ref.array_size = array_size

			fields.append(StructField(name=field_name, type_ref=type_ref, array_size=array_size, line=field_tok.line, col=field_tok.col))

		self._expect(TokenType.RBRACE)
		if self._peek().type == TokenType.SEMICOLON:
			self._advance()
		return StructDecl(name=name, fields=fields, line=tok.line, col=tok.col)

	def _parse_enum(self):
		tok = self._expect(TokenType.ENUM)
		name = self._expect(TokenType.IDENT).value
		self._expect(TokenType.LBRACE)

		variants = []
		while self._peek().type != TokenType.RBRACE:
			var_name = self._expect(TokenType.IDENT).value
			value = None
			if self._peek().type == TokenType.ASSIGN:
				self._advance()
				value = int(self._expect(TokenType.INT_LIT).value)
			variants.append(EnumVariant(name=var_name, value=value, line=self._peek().line, col=self._peek().col))
			if self._peek().type == TokenType.COMMA:
				self._advance()
			elif self._peek().type != TokenType.RBRACE:
				self._expect(TokenType.COMMA)

		self._expect(TokenType.RBRACE)
		if self._peek().type == TokenType.SEMICOLON:
			self._advance()
		return EnumDecl(name=name, variants=variants, line=tok.line, col=tok.col)

	def _parse_const(self):
		tok = self._expect(TokenType.CONST)
		name = self._expect(TokenType.IDENT).value
		self._expect(TokenType.COLON)
		type_name = self._expect(TokenType.IDENT).value
		type_ref = TypeRef(name=type_name, line=tok.line, col=tok.col)
		self._expect(TokenType.ASSIGN)
		value = self._parse_expr()
		self._expect(TokenType.SEMICOLON)
		return ConstDecl(name=name, type_ref=type_ref, value=value, line=tok.line, col=tok.col)

	def _parse_func(self):
		tok = self._expect(TokenType.FUNC)
		name = self._expect(TokenType.IDENT).value

		self._expect(TokenType.LPAREN)
		params = []
		if self._peek().type != TokenType.RPAREN:
			params = self._parse_params()
		self._expect(TokenType.RPAREN)

		return_type = TypeRef(name="void", line=tok.line, col=tok.col)
		if self._peek().type == TokenType.ARROW:
			self._advance()
			return_type = self._parse_type_ref()

		self._expect(TokenType.LBRACE)
		body = self._parse_block_body()
		self._expect(TokenType.RBRACE)

		return FuncDecl(name=name, params=params, return_type=return_type, body=body, line=tok.line, col=tok.col)

	def _parse_params(self):
		params = []
		while True:
			is_mut = False
			if self._peek().type == TokenType.MUT:
				self._advance()
				is_mut = True

			pname = self._expect(TokenType.IDENT).value
			self._expect(TokenType.COLON)
			ptype = self._parse_type_ref()

			params.append(Param(name=pname, type_ref=ptype, is_mut=is_mut, line=self._peek().line, col=self._peek().col))

			if self._peek().type == TokenType.COMMA:
				self._advance()
				continue
			break
		return params

	def _parse_type_ref(self):
		tok = self._peek()

		if tok.type == TokenType.FUNC:
			self._advance()
			self._expect(TokenType.LPAREN)
			param_types = []
			if self._peek().type != TokenType.RPAREN:
				while True:
					param_types.append(self._parse_type_ref())
					if self._peek().type == TokenType.COMMA:
						self._advance()
						continue
					break
			self._expect(TokenType.RPAREN)
			self._expect(TokenType.ARROW)
			ret_type = self._parse_type_ref()
			return ret_type

		is_mut = False
		if tok.type == TokenType.MUT:
			self._advance()
			is_mut = True

		if self._peek().type == TokenType.VOID:
			self._advance()
			type_name = "void"
		else:
			type_name = self._expect(TokenType.IDENT).value
		type_ref = TypeRef(name=type_name, is_mut=is_mut, line=tok.line, col=tok.col)

		while self._peek().type == TokenType.STAR:
			self._advance()
			type_ref.is_pointer = True

		if self._peek().type == TokenType.LBRACKET:
			self._advance()
			type_ref.is_array = True
			if self._peek().type == TokenType.IDENT or self._peek().type == TokenType.INT_LIT:
				size_tok = self._advance()
				type_ref.is_fixed_array = True
				type_ref.array_size = size_tok.value
			if self._peek().type == TokenType.SEMICOLON:
				self._advance()
				if self._peek().type != TokenType.RBRACKET:
					type_ref.array_size = self._advance().value
			self._expect(TokenType.RBRACKET)

		return type_ref

	def _parse_block_body(self):
		stmts = []
		while self._peek().type != TokenType.RBRACE and self._peek().type != TokenType.EOF:
			stmts.append(self._parse_statement())
		return stmts

	def _parse_statement(self):
		tok = self._peek()

		if tok.type == TokenType.LET:
			return self._parse_let()
		if tok.type == TokenType.IF:
			return self._parse_if()
		if tok.type == TokenType.MATCH:
			return self._parse_match()
		if tok.type == TokenType.MAP:
			return self._parse_map()
		if tok.type == TokenType.FILTER:
			return self._parse_filter()
		if tok.type == TokenType.FOLD:
			return self._parse_fold()
		if tok.type == TokenType.WHILE:
			return self._parse_while()
		if tok.type == TokenType.RETURN:
			return self._parse_return()
		if tok.type == TokenType.BREAK:
			self._advance()
			self._expect(TokenType.SEMICOLON)
			return BreakStmt(line=tok.line, col=tok.col)
		if tok.type == TokenType.CONTINUE:
			self._advance()
			self._expect(TokenType.SEMICOLON)
			return ContinueStmt(line=tok.line, col=tok.col)
		if tok.type == TokenType.C_PREFIX:
			return self._parse_c_call()

		return self._parse_expr_statement()

	def _parse_let(self):
		tok = self._expect(TokenType.LET)
		is_mut = False
		if self._peek().type == TokenType.MUT:
			self._advance()
			is_mut = True

		if self._peek().type == TokenType.LBRACE:
			self._advance()
			fields = []
			while self._peek().type != TokenType.RBRACE:
				fields.append(self._expect(TokenType.IDENT).value)
				if self._peek().type == TokenType.COMMA:
					self._advance()
			self._expect(TokenType.RBRACE)
			self._expect(TokenType.ASSIGN)
			value = self._parse_expr()
			self._expect(TokenType.SEMICOLON)
			return DestructureBinding(fields=fields, value=value, line=tok.line, col=tok.col)

		name = self._expect(TokenType.IDENT).value
		type_ref = None
		if self._peek().type == TokenType.COLON:
			self._advance()
			type_ref = self._parse_type_ref()

		value = None
		if self._peek().type == TokenType.ASSIGN:
			self._advance()
			value = self._parse_expr()

		self._expect(TokenType.SEMICOLON)
		return LetBinding(name=name, type_ref=type_ref, is_mut=is_mut, value=value, line=tok.line, col=tok.col)

	def _parse_if(self):
		tok = self._expect(TokenType.IF)
		cond = self._parse_expr()
		self._expect(TokenType.LBRACE)
		then_body = self._parse_block_body()
		self._expect(TokenType.RBRACE)

		else_body = []
		is_expr = False
		if self._peek().type == TokenType.ELSE:
			self._advance()
			if self._peek().type == TokenType.IF:
				else_body = [self._parse_if()]
				is_expr = else_body[0].is_expr
			else:
				self._expect(TokenType.LBRACE)
				else_body = self._parse_block_body()
				self._expect(TokenType.RBRACE)

		return IfExpr(cond=cond, then_body=then_body, else_body=else_body, is_expr=is_expr, line=tok.line, col=tok.col)

	def _parse_match(self):
		tok = self._expect(TokenType.MATCH)
		subject = self._parse_expr()
		self._expect(TokenType.LBRACE)

		arms = []
		while self._peek().type != TokenType.RBRACE:
			pattern = None
			is_wildcard = False

			if self._peek().type == TokenType.IDENT and self._peek().value == "_":
				self._advance()
				is_wildcard = True
			else:
				pattern = self._parse_expr()

			self._expect(TokenType.FAT_ARROW)
			self._expect(TokenType.LBRACE)
			body = self._parse_block_body()
			self._expect(TokenType.RBRACE)

			arms.append(MatchArm(pattern=pattern, body=body, is_wildcard=is_wildcard, line=tok.line, col=tok.col))

			if self._peek().type == TokenType.COMMA:
				self._advance()

		self._expect(TokenType.RBRACE)
		return MatchExpr(subject=subject, arms=arms, is_expr=False, line=tok.line, col=tok.col)

	def _parse_map(self):
		tok = self._expect(TokenType.MAP)
		self._expect(TokenType.LPAREN)
		index_var = self._expect(TokenType.IDENT).value
		self._expect(TokenType.IN)
		start = self._parse_expr()
		self._expect(TokenType.DOTDOT)
		end = self._parse_expr()
		inclusive = False
		if self._peek().type == TokenType.ASSIGN:
			self._advance()
			inclusive = True
		self._expect(TokenType.RPAREN)

		condition = None
		if self._peek().type == TokenType.WHERE:
			self._advance()
			condition = self._parse_expr()

		self._expect(TokenType.LBRACE)
		body = self._parse_block_body()
		self._expect(TokenType.RBRACE)

		return MapExpr(index_var=index_var, range=RangeExpr(start=start, end=end, inclusive=inclusive), condition=condition, body=body, line=tok.line, col=tok.col)

	def _parse_filter(self):
		tok = self._expect(TokenType.FILTER)
		self._expect(TokenType.LPAREN)
		index_var = self._expect(TokenType.IDENT).value
		self._expect(TokenType.IN)
		start = self._parse_expr()
		self._expect(TokenType.DOTDOT)
		end = self._parse_expr()
		self._expect(TokenType.RPAREN)

		condition = None
		if self._peek().type == TokenType.WHERE:
			self._advance()
			condition = self._parse_expr()

		self._expect(TokenType.SEMICOLON)
		return FilterExpr(index_var=index_var, range=RangeExpr(start=start, end=end), condition=condition, line=tok.line, col=tok.col)

	def _parse_fold(self):
		tok = self._expect(TokenType.FOLD)
		self._expect(TokenType.LPAREN)
		initial = self._parse_expr()
		self._expect(TokenType.COMMA)
		index_var = self._expect(TokenType.IDENT).value
		self._expect(TokenType.IN)
		start = self._parse_expr()
		self._expect(TokenType.DOTDOT)
		end = self._parse_expr()
		self._expect(TokenType.RPAREN)

		condition = None
		if self._peek().type == TokenType.WHERE:
			self._advance()
			condition = self._parse_expr()

		self._expect(TokenType.LBRACE)
		body = self._parse_block_body()
		self._expect(TokenType.RBRACE)

		return FoldExpr(initial=initial, index_var=index_var, range=RangeExpr(start=start, end=end), condition=condition, body=body, line=tok.line, col=tok.col)

	def _parse_while(self):
		tok = self._expect(TokenType.WHILE)
		cond = self._parse_expr()
		self._expect(TokenType.LBRACE)
		body = self._parse_block_body()
		self._expect(TokenType.RBRACE)
		return WhileLoop(cond=cond, body=body, line=tok.line, col=tok.col)

	def _parse_return(self):
		tok = self._expect(TokenType.RETURN)
		value = None
		if self._peek().type != TokenType.SEMICOLON:
			value = self._parse_expr()
		self._expect(TokenType.SEMICOLON)
		return ReturnStmt(value=value, line=tok.line, col=tok.col)

	def _parse_c_call(self):
		tok = self._expect(TokenType.C_PREFIX)
		name = self._expect(TokenType.IDENT).value
		self._expect(TokenType.LPAREN)
		args = []
		if self._peek().type != TokenType.RPAREN:
			while True:
				args.append(self._parse_expr())
				if self._peek().type == TokenType.COMMA:
					self._advance()
					continue
				break
		self._expect(TokenType.RPAREN)
		self._expect(TokenType.SEMICOLON)
		return Call(name=name, args=args, is_c_call=True, line=tok.line, col=tok.col)

	def _parse_expr_statement(self):
		tok = self._peek()

		if tok.type == TokenType.IDENT:
			next_tok = self._peek(1)
			if next_tok.type in (TokenType.INC, TokenType.DEC):
				return self._parse_inc_dec()

		expr = self._parse_expr()

		if self._peek().type == TokenType.ASSIGN:
			self._advance()
			value = self._parse_expr()
			if self._peek().type == TokenType.SEMICOLON:
				self._advance()
			return Assignment(target=expr, op="=", value=value, line=tok.line, col=tok.col)

		if self._peek().type in (TokenType.PLUS_ASSIGN, TokenType.MINUS_ASSIGN, TokenType.STAR_ASSIGN, TokenType.SLASH_ASSIGN, TokenType.PERCENT_ASSIGN):
			op_tok = self._advance()
			op_map = {
				TokenType.PLUS_ASSIGN: "+=",
				TokenType.MINUS_ASSIGN: "-=",
				TokenType.STAR_ASSIGN: "*=",
				TokenType.SLASH_ASSIGN: "/=",
				TokenType.PERCENT_ASSIGN: "%=",
			}
			op = op_map.get(op_tok.type, "+=")
			value = self._parse_expr()
			if self._peek().type == TokenType.SEMICOLON:
				self._advance()
			return Assignment(target=expr, op=op, value=value, line=tok.line, col=tok.col)

		if self._peek().type in (TokenType.INC, TokenType.DEC):
			op_tok = self._advance()
			op = "++" if op_tok.type == TokenType.INC else "--"
			if self._peek().type == TokenType.SEMICOLON:
				self._advance()
			return UnaryOp(op=op, operand=expr, prefix=False, line=tok.line, col=tok.col)

		if self._peek().type == TokenType.SEMICOLON:
			self._advance()
		return expr

	def _parse_assignment(self):
		target = self._parse_postfix()
		self._expect(TokenType.ASSIGN)
		value = self._parse_expr()
		self._expect(TokenType.SEMICOLON)
		return Assignment(target=target, op="=", value=value, line=target.line, col=target.col)

	def _parse_compound_assignment(self):
		target = self._parse_postfix()
		op_tok = self._advance()
		op_map = {
			TokenType.PLUS_ASSIGN: "+=",
			TokenType.MINUS_ASSIGN: "-=",
			TokenType.STAR_ASSIGN: "*=",
			TokenType.SLASH_ASSIGN: "/=",
			TokenType.PERCENT_ASSIGN: "%=",
		}
		op = op_map.get(op_tok.type, "+=")
		value = self._parse_expr()
		self._expect(TokenType.SEMICOLON)
		return Assignment(target=target, op=op, value=value, line=target.line, col=target.col)

	def _parse_inc_dec(self):
		target = self._parse_postfix()
		op_tok = self._advance()
		op = "++" if op_tok.type == TokenType.INC else "--"
		self._expect(TokenType.SEMICOLON)
		return UnaryOp(op=op, operand=target, prefix=False, line=target.line, col=target.col)

	def _parse_expr(self):
		return self._parse_or()

	def _parse_or(self):
		left = self._parse_and()
		while self._peek().type == TokenType.OR:
			tok = self._advance()
			right = self._parse_and()
			left = BinaryOp(op="||", left=left, right=right, line=tok.line, col=tok.col)
		return left

	def _parse_and(self):
		left = self._parse_equality()
		while self._peek().type == TokenType.AND:
			tok = self._advance()
			right = self._parse_equality()
			left = BinaryOp(op="&&", left=left, right=right, line=tok.line, col=tok.col)
		return left

	def _parse_equality(self):
		left = self._parse_comparison()
		while self._peek().type in (TokenType.EQ, TokenType.NEQ):
			tok = self._advance()
			op = "==" if tok.type == TokenType.EQ else "!="
			right = self._parse_comparison()
			left = BinaryOp(op=op, left=left, right=right, line=tok.line, col=tok.col)
		return left

	def _parse_comparison(self):
		left = self._parse_bitwise_or()
		while self._peek().type in (TokenType.LT, TokenType.GT, TokenType.LEQ, TokenType.GEQ):
			tok = self._advance()
			op_map = {TokenType.LT: "<", TokenType.GT: ">", TokenType.LEQ: "<=", TokenType.GEQ: ">="}
			op = op_map[tok.type]
			right = self._parse_bitwise_or()
			left = BinaryOp(op=op, left=left, right=right, line=tok.line, col=tok.col)
		return left

	def _parse_bitwise_or(self):
		left = self._parse_bitwise_xor()
		while self._peek().type == TokenType.PIPE:
			tok = self._advance()
			right = self._parse_bitwise_xor()
			left = BinaryOp(op="|", left=left, right=right, line=tok.line, col=tok.col)
		return left

	def _parse_bitwise_xor(self):
		left = self._parse_bitwise_and()
		while self._peek().type == TokenType.CARET:
			tok = self._advance()
			right = self._parse_bitwise_and()
			left = BinaryOp(op="^", left=left, right=right, line=tok.line, col=tok.col)
		return left

	def _parse_bitwise_and(self):
		left = self._parse_shift()
		while self._peek().type == TokenType.AMP:
			tok = self._advance()
			right = self._parse_shift()
			left = BinaryOp(op="&", left=left, right=right, line=tok.line, col=tok.col)
		return left

	def _parse_shift(self):
		left = self._parse_additive()
		while self._peek().type in (TokenType.SHL, TokenType.SHR):
			tok = self._advance()
			op = "<<" if tok.type == TokenType.SHL else ">>"
			right = self._parse_additive()
			left = BinaryOp(op=op, left=left, right=right, line=tok.line, col=tok.col)
		return left

	def _parse_additive(self):
		left = self._parse_multiplicative()
		while self._peek().type in (TokenType.PLUS, TokenType.MINUS):
			tok = self._advance()
			op = "+" if tok.type == TokenType.PLUS else "-"
			right = self._parse_multiplicative()
			left = BinaryOp(op=op, left=left, right=right, line=tok.line, col=tok.col)
		return left

	def _parse_multiplicative(self):
		left = self._parse_unary()
		while self._peek().type in (TokenType.STAR, TokenType.SLASH, TokenType.DOUBLE_SLASH, TokenType.PERCENT):
			tok = self._advance()
			op_map = {TokenType.STAR: "*", TokenType.SLASH: "/", TokenType.DOUBLE_SLASH: "//", TokenType.PERCENT: "%"}
			op = op_map[tok.type]
			right = self._parse_unary()
			left = BinaryOp(op=op, left=left, right=right, line=tok.line, col=tok.col)
		return left

	def _parse_unary(self):
		tok = self._peek()
		if tok.type in (TokenType.NOT, TokenType.TILDE, TokenType.MINUS, TokenType.AMP, TokenType.STAR, TokenType.INC, TokenType.DEC):
			self._advance()
			op_map = {
				TokenType.NOT: "!", TokenType.TILDE: "~", TokenType.MINUS: "-",
				TokenType.AMP: "&", TokenType.STAR: "*",
				TokenType.INC: "++", TokenType.DEC: "--",
			}
			op = op_map[tok.type]
			operand = self._parse_unary()
			return UnaryOp(op=op, operand=operand, prefix=True, line=tok.line, col=tok.col)
		return self._parse_postfix()

	def _parse_postfix(self):
		expr = self._parse_primary()

		while True:
			tok = self._peek()
			if tok.type == TokenType.LBRACKET:
				self._advance()
				index = self._parse_expr()
				self._expect(TokenType.RBRACKET)
				expr = IndexAccess(target=expr, index=index, line=tok.line, col=tok.col)
			elif tok.type == TokenType.DOT:
				self._advance()
				field_name = self._expect(TokenType.IDENT).value
				expr = FieldAccess(target=expr, field=field_name, line=tok.line, col=tok.col)
			elif tok.type == TokenType.LPAREN:
				if isinstance(expr, Identifier):
					self._advance()
					args = []
					if self._peek().type != TokenType.RPAREN:
						while True:
							args.append(self._parse_expr())
							if self._peek().type == TokenType.COMMA:
								self._advance()
								continue
							break
					self._expect(TokenType.RPAREN)
					expr = Call(name=expr.name, args=args, line=tok.line, col=tok.col)
				else:
					break
			elif tok.type in (TokenType.INC, TokenType.DEC):
				self._advance()
				op = "++" if tok.type == TokenType.INC else "--"
				expr = UnaryOp(op=op, operand=expr, prefix=False, line=tok.line, col=tok.col)
			else:
				break

		return expr

	def _parse_primary(self):
		tok = self._peek()

		if tok.type == TokenType.INT_LIT:
			self._advance()
			return Literal(value=tok.value, lit_type="int", line=tok.line, col=tok.col)
		if tok.type == TokenType.FLOAT_LIT:
			self._advance()
			return Literal(value=tok.value, lit_type="float", line=tok.line, col=tok.col)
		if tok.type == TokenType.CHAR_LIT:
			self._advance()
			return Literal(value=tok.value, lit_type="char", line=tok.line, col=tok.col)
		if tok.type == TokenType.STRING_LIT:
			self._advance()
			return Literal(value=tok.value, lit_type="string", line=tok.line, col=tok.col)
		if tok.type == TokenType.TRUE:
			self._advance()
			return Literal(value="true", lit_type="bool", line=tok.line, col=tok.col)
		if tok.type == TokenType.FALSE:
			self._advance()
			return Literal(value="false", lit_type="bool", line=tok.line, col=tok.col)
		if tok.type == TokenType.IDENT:
			self._advance()
			return Identifier(name=tok.value, line=tok.line, col=tok.col)
		if tok.type == TokenType.C_PREFIX:
			self._advance()
			name = self._expect(TokenType.IDENT).value
			if self._peek().type == TokenType.LPAREN:
				self._advance()
				args = []
				if self._peek().type != TokenType.RPAREN:
					while True:
						args.append(self._parse_expr())
						if self._peek().type == TokenType.COMMA:
							self._advance()
							continue
						break
				self._expect(TokenType.RPAREN)
				return Call(name=name, args=args, is_c_call=True, line=tok.line, col=tok.col)
			return Literal(value=name, lit_type="c_var", line=tok.line, col=tok.col)
		if tok.type == TokenType.LPAREN:
			self._advance()
			expr = self._parse_expr()
			self._expect(TokenType.RPAREN)
			return expr
		if tok.type == TokenType.LBRACE:
			return self._parse_struct_literal()
		if tok.type == TokenType.IF:
			return self._parse_if()

		self._error(f"unexpected token in expression: {tok.type.name} ('{tok.value}')")

	def _parse_struct_literal(self):
		tok = self._expect(TokenType.LBRACE)
		if self._peek().type == TokenType.RBRACE:
			self._advance()
			return Literal(value="{}", lit_type="zero_init", line=tok.line, col=tok.col)

		if self._peek().type == TokenType.INT_LIT or self._peek().type == TokenType.FLOAT_LIT:
			value = self._advance().value
			if self._peek().type == TokenType.RBRACE:
				self._advance()
			return Literal(value=value, lit_type="zero_init", line=tok.line, col=tok.col)

		if self._peek().type == TokenType.IDENT:
			first = self._advance()
			if self._peek().type == TokenType.COLON:
				fields = {}
				while True:
					if self._peek().type == TokenType.IDENT:
						field_name = self._advance().value
					else:
						break
					self._expect(TokenType.COLON)
					field_value = self._parse_expr()
					fields[field_name] = field_value
					if self._peek().type == TokenType.COMMA:
						self._advance()
						continue
					break
				self._expect(TokenType.RBRACE)
				return Literal(value=str(fields), lit_type="struct_init", line=tok.line, col=tok.col)

		self._error("invalid struct literal")
