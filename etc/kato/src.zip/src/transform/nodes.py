from dataclasses import dataclass, field
from typing import Optional, List


@dataclass
class TransformRule:
	"""A user-defined or built-in transform rule."""
	name: str = ""
	match_construct: str = ""
	match_op: Optional[str] = None
	condition: Optional[object] = None
	before_template: Optional[str] = None
	after_template: Optional[str] = None
	replace_template: Optional[str] = None
	enabled: bool = True

	def matches_construct(self, construct, op=None):
		if not self.enabled:
			return False
		if self.match_construct != construct:
			return False
		if self.match_op is not None and op is not None:
			if self.match_op != op:
				return False
		return True


@dataclass
class TransformDisable:
	name: str = ""
