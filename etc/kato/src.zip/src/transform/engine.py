from typing import Optional, List, Dict, Any

from src.transform.nodes import TransformRule
from src.metadata.nodes import Metadata
from src.metadata.evaluator import CTEvaluator
from src.parser.ast import (
	IndexAccess, BinaryOp, Assignment, Call, FieldAccess,
	UnaryOp, LetBinding, IfExpr, WhileLoop, MapExpr, FoldExpr,
	ReturnStmt, Identifier, Literal,
)


class TransformEngine:
	"""Interprets transform rules and generates C code snippets."""

	def __init__(self, meta: Metadata, evaluator: CTEvaluator):
		self.meta = meta
		self.evaluator = evaluator
		self.rules: List[TransformRule] = []
		self.disabled: set = set()
		self._register_defaults()

	def add_rule(self, rule: TransformRule):
		for i, existing in enumerate(self.rules):
			if existing.name == rule.name:
				self.rules[i] = rule
				return
		self.rules.append(rule)

	def disable_rule(self, name: str):
		self.disabled.add(name)
		for r in self.rules:
			if r.name == name:
				r.enabled = False

	def _register_defaults(self):
		if self.meta.is_safety():
			self._register_safety_defaults()
		else:
			self._register_speed_defaults()

	def _register_speed_defaults(self):
		pass

	def _register_safety_defaults(self):
		self.add_rule(TransformRule(
			name="safety_array_access",
			match_construct="array_access",
			condition=None,
			before_template=None,
		))
		self.add_rule(TransformRule(
			name="safety_binary_op",
			match_construct="binary_op",
			condition=None,
			before_template=None,
		))
		self.add_rule(TransformRule(
			name="safety_pointer_deref",
			match_construct="pointer_deref",
			condition=None,
			before_template=None,
		))

	def _eval_condition(self, condition) -> bool:
		if condition is None:
			return True
		try:
			return self.evaluator.eval_bool(condition)
		except Exception:
			return False

	def _get_panic_code(self) -> str:
		panic = self.meta.get_panic_mode() if self.meta else "halt"
		if panic == "abort":
			return "abort();"
		elif panic == "trap":
			return "__builtin_trap();"
		elif panic == "return":
			return "return 0;"
		else:
			return "/* halt */"

	def _get_meta_var(self, var_name: str) -> str:
		if var_name == "mode":
			return self.meta.mode if self.meta else "speed"
		if var_name == "bounds":
			return self.meta.bounds.mode if self.meta else "none"
		if var_name == "overflow":
			return self.meta.overflow.mode if self.meta else "unchecked"
		if var_name == "null_check":
			return self.meta.null_check.mode if self.meta else "never"
		if var_name == "div_check":
			return self.meta.div_check.mode if self.meta else "never"
		if var_name == "range_check":
			return self.meta.range_check.mode if self.meta else "never"
		if var_name == "alloc":
			return self.meta.alloc.strategy if self.meta else "dynamic"
		if var_name == "panic":
			return self.meta.panic.mode if self.meta else "halt"
		if var_name == "init":
			return self.meta.init.mode if self.meta else "none"
		return ""

	def _fill_template(self, template: str, variables: Dict[str, str]) -> str:
		import re

		parts = re.split(r'("[^"]*")', template)
		result = []

		for part in parts:
			if part.startswith('"') and part.endswith('"'):
				for key, val in variables.items():
					part = part.replace("{" + key + "}", str(val))
				result.append(part)
			else:
				def replace_var(match):
					key = match.group(1).strip()
					if key == "panic_code":
						return self._get_panic_code()
					if key in variables:
						return str(variables[key])
					return match.group(0)
				result.append(re.sub(r'\{([^}]+)\}', replace_var, part))

		return "".join(result)

	def _extract_variables(self, node, construct: str, codegen) -> Dict[str, str]:
		vars = {}

		if construct == "array_access" and isinstance(node, IndexAccess):
			vars["target"] = codegen._gen_expr(node.target)
			vars["index"] = codegen._gen_expr(node.index)
			vars["original"] = codegen._gen_expr(node)
			capacity = self._find_capacity(node, codegen)
			vars["capacity"] = capacity or "0"

		elif construct == "binary_op" and isinstance(node, BinaryOp):
			vars["left"] = codegen._gen_expr(node.left)
			vars["right"] = codegen._gen_expr(node.right)
			vars["op"] = node.op
			vars["original"] = codegen._gen_expr(node)
			type_max, type_min = self._find_type_bounds(node, codegen)
			vars["type_max"] = str(type_max)
			vars["type_min"] = str(type_min)

		elif construct == "assignment" and isinstance(node, Assignment):
			vars["target"] = codegen._gen_expr(node.target)
			vars["value"] = codegen._gen_expr(node.value)
			vars["original"] = f"{vars['target']} {node.op} {vars['value']}"

		elif construct == "function_call" and isinstance(node, Call):
			vars["name"] = node.name
			vars["args"] = ", ".join(codegen._gen_expr(a) for a in node.args)
			vars["original"] = codegen._gen_expr(node)

		elif construct == "field_access" and isinstance(node, FieldAccess):
			vars["target"] = codegen._gen_expr(node.target)
			vars["field"] = node.field
			vars["original"] = codegen._gen_expr(node)

		elif construct == "pointer_deref" and isinstance(node, UnaryOp) and node.op == "*":
			vars["pointer"] = codegen._gen_expr(node.operand)
			vars["original"] = codegen._gen_expr(node)

		elif construct == "address_of" and isinstance(node, UnaryOp) and node.op == "&":
			vars["target"] = codegen._gen_expr(node.operand)
			vars["original"] = codegen._gen_expr(node)

		elif construct == "if_stmt" and isinstance(node, IfExpr):
			vars["cond"] = codegen._gen_expr(node.cond)
			vars["original"] = "/* if block */"

		elif construct == "while_loop" and isinstance(node, WhileLoop):
			vars["cond"] = codegen._gen_expr(node.cond)
			vars["original"] = "/* while loop */"

		elif construct == "map_loop" and isinstance(node, MapExpr):
			vars["index_var"] = node.index_var
			vars["range_start"] = codegen._gen_expr(node.range.start)
			vars["range_end"] = codegen._gen_expr(node.range.end)
			vars["original"] = "/* map loop */"

		elif construct == "fold_expr" and isinstance(node, FoldExpr):
			vars["index_var"] = node.index_var
			vars["range_start"] = codegen._gen_expr(node.range.start)
			vars["range_end"] = codegen._gen_expr(node.range.end)
			vars["original"] = "/* fold expr */"

		elif construct == "return_stmt" and isinstance(node, ReturnStmt):
			vars["value"] = codegen._gen_expr(node.value) if node.value else ""
			vars["original"] = f"return {vars['value']};" if vars["value"] else "return;"

		elif construct == "let_binding" and isinstance(node, LetBinding):
			vars["name"] = node.name
			type_name = codegen._c_type(node.type_ref) if node.type_ref else "int"
			vars["type"] = type_name
			vars["value"] = codegen._gen_expr(node.value) if node.value else "0"
			vars["original"] = f"{type_name} {node.name} = {vars['value']};" if node.value else f"{type_name} {node.name};"

		return vars

	def _find_capacity(self, node: IndexAccess, codegen) -> Optional[str]:
		if not self.meta:
			return None
		if isinstance(node.target, FieldAccess):
			if isinstance(node.target.target, Identifier):
				var_name = node.target.target.name
				if var_name in codegen.pointer_vars:
					td = None
					for s in codegen.program.structs:
						td = self.meta.get_type_def(s.name)
						if td and node.target.field in td.fields:
							arr = td.field_arrays.get(node.target.field)
							if arr is not None:
								from src.metadata.evaluator import CTEvaluator
								ev = CTEvaluator(self.meta.let_bindings)
								try:
									return str(ev.eval_int(arr))
								except Exception:
									return self._ct_expr_to_c(arr)
							return s.name
					return None
		return None

	def _find_type_bounds(self, node: BinaryOp, codegen):
		if not self.meta:
			return (2147483647, -2147483648)
		return (2147483647, -2147483648)

	def _ct_expr_to_c(self, expr) -> str:
		from src.metadata.nodes import CTInt, CTFloat, CTRef, CTBinary, CTUnary
		if isinstance(expr, CTInt):
			return str(expr.value)
		if isinstance(expr, CTRef):
			return expr.name
		if isinstance(expr, CTBinary):
			return f"({self._ct_expr_to_c(expr.left)} {expr.op} {self._ct_expr_to_c(expr.right)})"
		if isinstance(expr, CTUnary):
			return f"({expr.op}{self._ct_expr_to_c(expr.operand)})"
		return "0"

	def find_rule(self, construct: str, op: str = None) -> Optional[TransformRule]:
		for rule in self.rules:
			if not rule.enabled:
				continue
			if rule.name in self.disabled:
				continue
			if not rule.matches_construct(construct, op):
				continue
			if not self._eval_condition(rule.condition):
				continue
			return rule
		return None

	def apply(self, node, construct: str, codegen, op: str = None) -> Optional[dict]:
		"""Check if a transform rule applies to this node.
		Returns dict with 'before', 'after', 'replace' C code, or None."""
		rule = self.find_rule(construct, op)
		if rule is None:
			return None

		vars = self._extract_variables(node, construct, codegen)
		if not vars:
			return None

		result = {"before": None, "after": None, "replace": None}

		if rule.before_template:
			result["before"] = self._fill_template(rule.before_template, vars)
		if rule.after_template:
			result["after"] = self._fill_template(rule.after_template, vars)
		if rule.replace_template:
			result["replace"] = self._fill_template(rule.replace_template, vars)

		if result["before"] is None and result["after"] is None and result["replace"] is None:
			return None

		return result
